* =====================================================
*  Efficient GAMS Model
*  Using Sets and Explicit Windows
* =====================================================

SETS
    h   hours   /0*23/
    w   windows /0*23/;

ALIAS (h, h1);

SET
    win(w,h) window definitions
    /
    0.(18,19,20,22,23,0)
    1.(19,20,21,23,0,1)
    2.(20,21,22,0,1,2)
    3.(21,22,23,1,2,3)
    4.(22,23,0,2,3,4)
    5.(23,0,1,3,4,5)
    6.(0,1,2,4,5,6)
    7.(1,2,3,5,6,7)
    8.(2,3,4,6,7,8)
    9.(3,4,5,7,8,9)
    10.(4,5,6,8,9,10)
    11.(5,6,7,9,10,11)
    12.(6,7,8,10,11,12)
    13.(7,8,9,11,12,13)
    14.(8,9,10,12,13,14)
    15.(9,10,11,13,14,15)
    16.(10,11,12,14,15,16)
    17.(11,12,13,15,16,17)
    18.(12,13,14,16,17,18)
    19.(13,14,15,17,18,19)
    20.(14,15,16,18,19,20)
    21.(15,16,17,19,20,21)
    22.(16,17,18,20,21,22)
    23.(17,18,19,21,22,23)
    /;

PARAMETERS
    wage(h)
    /
    0 189, 1 189, 2 189, 3 180, 4 171, 5 162
    6 153, 7 144, 8 135, 9 126, 10 126, 11 135
    12 144, 13 153, 14 162, 15 171, 16 180, 17 189
    18 189, 19 189, 20 189, 21 189, 22 189, 23 189
    /

    demX(w)
    /
    0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110
    8 140, 9 200, 10 180, 11 180, 12 240, 13 220
    14 220, 15 230, 16 250, 17 260, 18 230, 19 250
    20 260, 21 250, 22 220, 23 190
    /

    demY(w)
    /
    0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90
    8 110, 9 110, 10 110, 11 130, 12 150, 13 160
    14 120, 15 130, 16 160, 17 180, 18 200, 19 170
    20 140, 21 110, 22 100, 23 90
    /

    sMinusCost(w)
    /
    0 30, 1 30, 2 30, 3 30, 4 30, 5 30, 6 30
    7 60, 8 60, 9 60, 10 60, 11 60, 12 60, 13 60
    14 60, 15 60, 16 60, 17 60, 18 30, 19 30
    20 30, 21 30, 22 30, 23 30
    /

    sPrimeCost /45/;

VARIABLES
    z;

INTEGER VARIABLES
    x(h), y(h),
    s_plus(w), s_minus(w), s_prime_plus(w), s_prime_minus(w);

* bounds for integer vars
x.lo(h) = 0;
y.lo(h) = 0;
s_plus.lo(w)        = 0;
s_minus.lo(w)       = 0;
s_prime_plus.lo(w)  = 0;
s_prime_minus.lo(w) = 0;

EQUATIONS
    capacity(h)
    winCapMax(w)
    winCapMin(w)
    demXLow(w)
    demXUp(w)
    demYLow(w)
    demYUp(w)
    sMinusBound(w)
    sPrimeMinusBound(w)
    total_s_minus
    total_s_prime_minus
    obj;

capacity(h).. x(h) + y(h) =L= 100;

winCapMax(w).. sum(h1$win(w,h1), x(h1) + y(h1)) =L= 420;
winCapMin(w).. sum(h1$win(w,h1), x(h1) + y(h1)) =G= 80;

demXLow(w).. sum(h1$win(w,h1), x(h1)) =G= demX(w) - s_minus(w);
demXUp(w)..  sum(h1$win(w,h1), x(h1)) =L= demX(w) + s_plus(w);

demYLow(w).. sum(h1$win(w,h1), y(h1)) =G= demY(w) - s_prime_minus(w);
demYUp(w)..  sum(h1$win(w,h1), y(h1)) =L= demY(w) + s_prime_plus(w);

sMinusBound(w)..       s_minus(w)       =L= 10;
sPrimeMinusBound(w)..  s_prime_minus(w) =L= 10;

total_s_minus..       sum(w, s_minus(w))       =L= 40;
total_s_prime_minus.. sum(w, s_prime_minus(w)) =L= 30;

obj..
    z =E=
        sum(h, wage(h)*(x(h) + y(h)))
      + sum(w, sMinusCost(w)*s_minus(w))
      + sPrimeCost * sum(w, s_prime_minus(w));

MODEL CallCenter /all/;
OPTION optcr = 0.0001;
* ==========================================
* Sensitivity Analysis on wage(4)
* Range: 100..300 step 5
* ==========================================

SET sc /sc0*sc40/;   
PARAMETER
    wageBase(h)
    c4(sc)          "tested wage(4) values"
    objVal(sc)      "objective value z"
    modelStat(sc)
    solveStat(sc);

wageBase(h) = wage(h);
c4(sc) = 100 + 5*(ord(sc)-1);

OPTION optcr = 0.0001;

LOOP(sc,
    wage(h) = wageBase(h);
    wage('4') = c4(sc);

    SOLVE CallCenter USING MIP MINIMIZING z;

    objVal(sc)   = z.l;
    modelStat(sc)= CallCenter.modelstat;
    solveStat(sc)= CallCenter.solvestat;
);

DISPLAY c4, objVal, modelStat, solveStat;


FILE fout /sens_wage4.csv/;
PUT fout;
PUT "wage4,z,modelstat,solvestat" /;
LOOP(sc,
    PUT c4(sc):0:0 "," objVal(sc):0:6 "," modelStat(sc):0:0 "," solveStat(sc):0:0 /;
);
PUTCLOSE fout;

