
*  Sensitivity on ONE s_prime_minus(w)


SETS
    h   hours   /0*23/
    w   windows /0*23/;

ALIAS (h, h1);

SET
    win(w,h)
    /
    0.(18,19,20,22,23,0)
    1.(19,20,21,23,0,1)
    2.(20,21,22,0,1,2)
    3.(21,22,23,1,2,3)
    4.(22,23,0,2,3,4)
    5.(23,0,1,3,4,5)
    6.(0,1,2,4,5,6)
    7.(1,2,3,5,6,7)
    8.(2,3,4,6,7,8)
    9.(3,4,5,7,8,9)
    10.(4,5,6,8,9,10)
    11.(5,6,7,9,10,11)
    12.(6,7,8,10,11,12)
    13.(7,8,9,11,12,13)
    14.(8,9,10,12,13,14)
    15.(9,10,11,13,14,15)
    16.(10,11,12,14,15,16)
    17.(11,12,13,15,16,17)
    18.(12,13,14,16,17,18)
    19.(13,14,15,17,18,19)
    20.(14,15,16,18,19,20)
    21.(15,16,17,19,20,21)
    22.(16,17,18,20,21,22)
    23.(17,18,19,21,22,23)
    /;

PARAMETERS
    wage(h)
    /
    0 189, 1 189, 2 189, 3 180, 4 171, 5 162
    6 153, 7 144, 8 135, 9 126, 10 126, 11 135
    12 144, 13 153, 14 162, 15 171, 16 180, 17 189
    18 189, 19 189, 20 189, 21 189, 22 189, 23 189
    /

    demX(w)
    /
    0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110
    8 140, 9 200, 10 180, 11 180, 12 240, 13 220
    14 220, 15 230, 16 250, 17 260, 18 230, 19 250
    20 260, 21 250, 22 220, 23 190
    /

    demY(w)
    /
    0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90
    8 110, 9 110, 10 110, 11 130, 12 150, 13 160
    14 120, 15 130, 16 160, 17 180, 18 200, 19 170
    20 140, 21 110, 22 100, 23 90
    /

    sMinusCost(w)
    /
    0 30, 1 30, 2 30, 3 30, 4 30, 5 30, 6 30
    7 60, 8 60, 9 60, 10 60, 11 60, 12 60, 13 60
    14 60, 15 60, 16 60, 17 60, 18 30, 19 30
    20 30, 21 30, 22 30, 23 30
    /

    sPrimeCost /45/
    sMinusCap(w)
    sPrimeMinusCap(w)
    ;

VARIABLES
    z;

INTEGER VARIABLES
    x(h), y(h);

POSITIVE VARIABLES
    s_plus(w), s_minus(w), s_prime_plus(w), s_prime_minus(w);

EQUATIONS
    capacity(h)
    winCapMax(w)
    winCapMin(w)
    demXLow(w)
    demXUp(w)
    demYLow(w)
    demYUp(w)
    sMinusBound(w)
    sPrimeMinusBound(w)
    total_s_minus
    total_s_prime_minus
    obj;

capacity(h).. x(h) + y(h) =L= 100;

winCapMax(w).. sum(h1$win(w,h1), x(h1) + y(h1)) =L= 420;
winCapMin(w).. sum(h1$win(w,h1), x(h1) + y(h1)) =G= 80;

demXLow(w).. sum(h1$win(w,h1), x(h1)) =G= demX(w) - s_minus(w);
demXUp(w)..  sum(h1$win(w,h1), x(h1)) =L= demX(w) + s_plus(w);

demYLow(w).. sum(h1$win(w,h1), y(h1)) =G= demY(w) - s_prime_minus(w);
demYUp(w)..  sum(h1$win(w,h1), y(h1)) =L= demY(w) + s_prime_plus(w);

sMinusBound(w)..      s_minus(w)       =L= 10;
sPrimeMinusBound(w).. s_prime_minus(w) =L= sPrimeMinusCap(w);

total_s_minus..       sum(w, s_minus(w))       =L= 40;
total_s_prime_minus.. sum(w, s_prime_minus(w)) =L= 30;

obj..
    z =E=
        sum(h, wage(h)*(x(h) + y(h)))
      + sum(w, sMinusCost(w)*s_minus(w))
      + sPrimeCost * sum(w, s_prime_minus(w));

MODEL CallCenter /all/;
OPTION optcr = 0.0001;


*  INITIAL SOLUTION (Warm Start)

Parameter 
    x_init(h),
    y_init(h),
    sminus_init(w),
    sprime_init(w)
    splus_init(w),
    sprimeplus_init(w);

x_init(h) =
      6$(ord(h)=5)   + 33$(ord(h)=6)   + 21$(ord(h)=7)
    + 56$(ord(h)=8)  + 57$(ord(h)=9)   + 48$(ord(h)=10)
    + 16$(ord(h)=11) + 43$(ord(h)=12)  + 47$(ord(h)=13)
    + 2$(ord(h)=14)  + 50$(ord(h)=15)  + 71$(ord(h)=16)
    + 26$(ord(h)=17) + 61$(ord(h)=18)  + 40$(ord(h)=19)
    + 26$(ord(h)=20) + 37$(ord(h)=21)  + 29$(ord(h)=22)
    + 24$(ord(h)=23);

y_init(h) =
      4$(ord(h)=2)   + 13$(ord(h)=4)   + 24$(ord(h)=5)
    + 29$(ord(h)=7)  + 44$(ord(h)=8)   + 29$(ord(h)=10)
    + 28$(ord(h)=11) + 49$(ord(h)=13)  + 38$(ord(h)=14)
    + 23$(ord(h)=15) + 29$(ord(h)=16)  + 31$(ord(h)=17)
    + 23$(ord(h)=18) + 30$(ord(h)=19)  + 24$(ord(h)=20)
    + 3$(ord(h)=21)  + 13$(ord(h)=23);

sminus_init(w) =
      3$(ord(w)=2)   + 10$(ord(w)=18)  + 4$(ord(w)=19)
    + 10$(ord(w)=21) + 3$(ord(w)=23)   + 10$(ord(w)=24);

sprime_init(w) =
      9$(ord(w)=2)   + 10$(ord(w)=18)
    + 6$(ord(w)=19)  + 3$(ord(w)=20);

splus_init(w) =
      7$(ord(w)=1)
    + 3$(ord(w)=4)
    + 9$(ord(w)=6)
    + 1$(ord(w)=11)
    + 37$(ord(w)=12)
    + 33$(ord(w)=14)
    + 3$(ord(w)=17);

sprimeplus_init(w) =
      1$(ord(w)=6)
    + 17$(ord(w)=7)
    + 47$(ord(w)=15)
    + 17$(ord(w)=16);

x.l(h)              = x_init(h);
y.l(h)              = y_init(h);
s_minus.l(w)        = sminus_init(w);
s_prime_minus.l(w)  = sprime_init(w);
s_plus.l(w)        = splus_init(w);
s_prime_plus.l(w)  = sprimeplus_init(w);


* Store initial solution
Parameter x0(h), y0(h), sminus0(w), sprime0(w) ,splus0(w) , sprimeplus0(w);
x0(h)      = x.l(h);
y0(h)      = y.l(h);
sminus0(w) = s_minus.l(w);
sprime0(w) = s_prime_minus.l(w);
splus0(w) = s_plus.l(w);
sprimeplus0(w) = s_prime_plus.l(w);
 
    


*  SENSITIVITY ANALYSIS on ONE s_prime_minus


Scalar index_to_change, cap_value, base_obj, feasible, wx, wy;

index_to_change = 17;
cap_value       = 10;

sPrimeMinusCap(w) = 10;
sPrimeMinusCap(w)$(ord(w)-1 = index_to_change) = cap_value;

Solve CallCenter using mip minimizing z;
base_obj = z.l;

display "Base objective =", base_obj;

Set capset /cap0*cap200/;
Parameter capVal(capset);
capVal(capset) = ord(capset) - 1;


*  UPPER BOUND SEARCH


loop(capset$(capVal(capset) > cap_value),

    cap_value = capVal(capset);

    feasible = 1;

    if(sum(w, sminus0(w)) > 40, feasible = 0);
    if(sum(w, sprime0(w)) > 30, feasible = 0);

    loop(h, if(x0(h) + y0(h) > 100, feasible = 0));

    loop(w,
        if(sprime0(w) >
            (10$(ord(w)-1 <> index_to_change)
           + cap_value$(ord(w)-1 = index_to_change)),
            feasible = 0
        );
    );

    loop(w, if(sminus0(w) > 10, feasible = 0));

    loop(w,
        wx = sum(h1$win(w,h1), x0(h1));
        wy = sum(h1$win(w,h1), y0(h1));

        if(wx < demX(w) - sminus0(w), feasible = 0);
        if(wy < demY(w) - sprime0(w), feasible = 0);
    );

    if(feasible = 0,
        display "❌ infeasible at cap =", cap_value;
        break;
    );

    sPrimeMinusCap(w) = 10;
    sPrimeMinusCap(w)$(ord(w)-1 = index_to_change) = cap_value;

    Solve CallCenter using mip minimizing z;

    if(z.l < base_obj - 1e-6,
        display "⭐ improvement at cap =", cap_value, "objective =", z.l;
        break;
    );

);


*  LOWER BOUND SEARCH


loop(capset$(capVal(capset) < 10),

    cap_value = 9 - capVal(capset);

    feasible = 1;

    if(sum(w, sminus0(w)) > 40, feasible = 0);
    if(sum(w, sprime0(w)) > 30, feasible = 0);

    loop(h, if(x0(h) + y0(h) > 100, feasible = 0));

    loop(w,
        if(sprime0(w) >
            (10$(ord(w)-1 <> index_to_change)
           + cap_value$(ord(w)-1 = index_to_change)),
            feasible = 0
        );
    );

    loop(w, if(sminus0(w) > 10, feasible = 0));

    loop(w,
        wx = sum(h1$win(w,h1), x0(h1));
        wy = sum(h1$win(w,h1), y0(h1));

        if(wx < demX(w) - sminus0(w), feasible = 0);
        if(wy < demY(w) - sprime0(w), feasible = 0);
    );

    if(feasible = 0,
        display "❌ infeasible at cap =", cap_value;
        break;
    );

    sPrimeMinusCap(w) = 10;
    sPrimeMinusCap(w)$(ord(w)-1 = index_to_change) = cap_value;

    Solve CallCenter using mip minimizing z;

    if(z.l < base_obj - 1e-6,
        display "⭐ improvement at cap =", cap_value, "objective =", z.l;
        break;
    );

);

display "Sensitivity analysis completed.";
