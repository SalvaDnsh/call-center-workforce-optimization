* تنظیمات اولیه
Option limrow = 0;
Option limcol = 0;
Option solprint = off;
Option mip = gurobi;
* تنظیم Gap روی صفر برای اطمینان از بهینگی مطلق مثل کد پایتون
Option optcr = 0.0;
Option optca = 0.0;

* 1. تعریف مجموعه‌ها و پارامترها (Sets & Parameters)
Sets
    h "Hours" /0*23/
    w "Windows" /0*23/
;

* نگاشت پنجره‌های زمانی دقیقاً طبق کد پایتون
Set map_win(w, h);
map_win(w, h) = no;

* تعریف دستی پنجره‌ها طبق لیست Python
map_win('0', '18')=yes; map_win('0', '19')=yes; map_win('0', '20')=yes; map_win('0', '22')=yes; map_win('0', '23')=yes; map_win('0', '0')=yes;
map_win('1', '19')=yes; map_win('1', '20')=yes; map_win('1', '21')=yes; map_win('1', '23')=yes; map_win('1', '0')=yes; map_win('1', '1')=yes;
map_win('2', '20')=yes; map_win('2', '21')=yes; map_win('2', '22')=yes; map_win('2', '0')=yes; map_win('2', '1')=yes; map_win('2', '2')=yes;
map_win('3', '21')=yes; map_win('3', '22')=yes; map_win('3', '23')=yes; map_win('3', '1')=yes; map_win('3', '2')=yes; map_win('3', '3')=yes;
map_win('4', '22')=yes; map_win('4', '23')=yes; map_win('4', '0')=yes; map_win('4', '2')=yes; map_win('4', '3')=yes; map_win('4', '4')=yes;
map_win('5', '23')=yes; map_win('5', '0')=yes; map_win('5', '1')=yes; map_win('5', '3')=yes; map_win('5', '4')=yes; map_win('5', '5')=yes;
map_win('6', '0')=yes; map_win('6', '1')=yes; map_win('6', '2')=yes; map_win('6', '4')=yes; map_win('6', '5')=yes; map_win('6', '6')=yes;
map_win('7', '1')=yes; map_win('7', '2')=yes; map_win('7', '3')=yes; map_win('7', '5')=yes; map_win('7', '6')=yes; map_win('7', '7')=yes;
map_win('8', '2')=yes; map_win('8', '3')=yes; map_win('8', '4')=yes; map_win('8', '6')=yes; map_win('8', '7')=yes; map_win('8', '8')=yes;
map_win('9', '3')=yes; map_win('9', '4')=yes; map_win('9', '5')=yes; map_win('9', '7')=yes; map_win('9', '8')=yes; map_win('9', '9')=yes;
map_win('10', '4')=yes; map_win('10', '5')=yes; map_win('10', '6')=yes; map_win('10', '8')=yes; map_win('10', '9')=yes; map_win('10', '10')=yes;
map_win('11', '5')=yes; map_win('11', '6')=yes; map_win('11', '7')=yes; map_win('11', '9')=yes; map_win('11', '10')=yes; map_win('11', '11')=yes;
map_win('12', '6')=yes; map_win('12', '7')=yes; map_win('12', '8')=yes; map_win('12', '10')=yes; map_win('12', '11')=yes; map_win('12', '12')=yes;
map_win('13', '7')=yes; map_win('13', '8')=yes; map_win('13', '9')=yes; map_win('13', '11')=yes; map_win('13', '12')=yes; map_win('13', '13')=yes;
map_win('14', '8')=yes; map_win('14', '9')=yes; map_win('14', '10')=yes; map_win('14', '12')=yes; map_win('14', '13')=yes; map_win('14', '14')=yes;
map_win('15', '9')=yes; map_win('15', '10')=yes; map_win('15', '11')=yes; map_win('15', '13')=yes; map_win('15', '14')=yes; map_win('15', '15')=yes;
map_win('16', '10')=yes; map_win('16', '11')=yes; map_win('16', '12')=yes; map_win('16', '14')=yes; map_win('16', '15')=yes; map_win('16', '16')=yes;
map_win('17', '11')=yes; map_win('17', '12')=yes; map_win('17', '13')=yes; map_win('17', '15')=yes; map_win('17', '16')=yes; map_win('17', '17')=yes;
map_win('18', '12')=yes; map_win('18', '13')=yes; map_win('18', '14')=yes; map_win('18', '16')=yes; map_win('18', '17')=yes; map_win('18', '18')=yes;
map_win('19', '13')=yes; map_win('19', '14')=yes; map_win('19', '15')=yes; map_win('19', '17')=yes; map_win('19', '18')=yes; map_win('19', '19')=yes;
map_win('20', '14')=yes; map_win('20', '15')=yes; map_win('20', '16')=yes; map_win('20', '18')=yes; map_win('20', '19')=yes; map_win('20', '20')=yes;
map_win('21', '15')=yes; map_win('21', '16')=yes; map_win('21', '17')=yes; map_win('21', '19')=yes; map_win('21', '20')=yes; map_win('21', '21')=yes;
map_win('22', '16')=yes; map_win('22', '17')=yes; map_win('22', '18')=yes; map_win('22', '20')=yes; map_win('22', '21')=yes; map_win('22', '22')=yes;
map_win('23', '17')=yes; map_win('23', '18')=yes; map_win('23', '19')=yes; map_win('23', '21')=yes; map_win('23', '22')=yes; map_win('23', '23')=yes;

Parameters
    demands_x(w)
    /
    0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110, 8 140, 9 200, 10 180, 11 180,
    12 240, 13 220, 14 220, 15 230, 16 250, 17 260, 18 230, 19 250, 20 260, 21 250, 22 220, 23 190
    /

    demands_y(w)
    /
    0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90, 8 110, 9 110, 10 110, 11 130,
    12 150, 13 160, 14 120, 15 130, 16 160, 17 180, 18 200, 19 170, 20 140, 21 110, 22 100, 23 90
    /

    weights(h)
    /
    0 189, 1 189, 2 189, 3 180, 4 171, 5 162, 6 153, 7 144, 8 135, 9 126, 10 126, 11 135,
    12 144, 13 153, 14 162, 15 171, 16 180, 17 189, 18 189, 19 189, 20 189, 21 189, 22 189, 23 189
    /

* هزینه پنالتی برای s_minus بر اساس بازه زمانی
    penalty_s_minus(w)
;

* محاسبه مقادیر penalty_s_minus مشابه کد پایتون
penalty_s_minus(w) = 0;
penalty_s_minus(w)$(ord(w)>=8 and ord(w)<=18) = 60;  
penalty_s_minus(w)$(ord(w)>=19 or ord(w)<=7) = 30;   

Scalars
    demand_index_to_change /10/
    base_cap /110/
    MIN_CAP /0/
    MAX_CAP /300/
;

* 2. متغیرها و معادلات
Variables
    z "Objective function value"
;

Integer Variables
    x(h) "x vars"
    y(h) "y vars"
    s_plus(w)
    s_minus(w)
    s_prime_plus(w)
    s_prime_minus(w)
;

* کران‌های متغیرها
x.lo(h) = 0; y.lo(h) = 0;
s_plus.lo(w) = 0; s_minus.lo(w) = 0;
s_prime_plus.lo(w) = 0; s_prime_minus.lo(w) = 0;

* کران‌های slack (طبق کد: <= 10)
s_minus.up(w) = 10;
s_prime_minus.up(w) = 10;

Equations
    ObjDef "Objective Function"
    CapConstr(h) "x[i] + y[i] <= 100"
    WinCapMax(w) "Sum <= 420"
    WinCapMin(w) "Sum >= 80"
    DemandX_Low(w) "Lower bound for X demand"
    DemandX_High(w) "Upper bound for X demand"
    DemandY_Low(w) "Lower bound for Y demand"
    DemandY_High(w) "Upper bound for Y demand"
    TotalSMinus "Sum s_minus <= 40"
    TotalSPrimeMinus "Sum s_prime_minus <= 30"
;

ObjDef..
    z =e= sum(h, weights(h) * (x(h) + y(h)))
        + sum(w, penalty_s_minus(w) * s_minus(w))
        + 45 * sum(w, s_prime_minus(w));

CapConstr(h)..
    x(h) + y(h) =l= 100;

WinCapMax(w)..
    sum(h$map_win(w, h), x(h) + y(h)) =l= 420;

WinCapMin(w)..
    sum(h$map_win(w, h), x(h) + y(h)) =g= 80;

* پارامتر cap_value باید در حلقه تغییر کند
Parameter cap_value;
cap_value = base_cap;

* قیود تقاضا برای x همیشه ثابت
DemandX_Low(w)..
    sum(h$map_win(w, h), x(h)) =g= demands_x(w) - s_minus(w);

DemandX_High(w)..
    sum(h$map_win(w, h), x(h)) =l= demands_x(w) + s_plus(w);

* قیود تقاضا برای y با تغییر در پنجره demand_index_to_change
DemandY_Low(w)..
    sum(h$map_win(w, h), y(h)) =g= demands_y(w) - s_prime_minus(w)
    + (cap_value - demands_y(w))$(ord(w) = demand_index_to_change+1);

DemandY_High(w)..
    sum(h$map_win(w, h), y(h)) =l= demands_y(w) + s_prime_plus(w)
    + (cap_value - demands_y(w))$(ord(w) = demand_index_to_change+1);

TotalSMinus..
    sum(w, s_minus(w)) =l= 40;

TotalSPrimeMinus..
    sum(w, s_prime_minus(w)) =l= 30;

Model CapacityModel /all/;

* 3. ذخیره‌سازی جواب پایه (Base Solution Storage)
Parameters
    init_x(h)
    / 0 0, 1 0, 2 0, 3 0, 4 6, 5 33, 6 21, 7 56, 8 57, 9 48, 10 16, 11 43,
      12 47, 13 2, 14 50, 15 71, 16 26, 17 61, 18 40, 19 26, 20 37, 21 29, 22 24, 23 0 /

    init_y(h)
    / 0 0, 1 4, 2 0, 3 13, 4 24, 5 0, 6 29, 7 44, 8 0, 9 29, 10 28, 11 0,
      12 49, 13 38, 14 23, 15 29, 16 31, 17 23, 18 30, 19 24, 20 3, 21 0, 22 13, 23 0 /

    init_s_minus(w)
    / 0 0, 1 3, 2 0, 3 0, 4 0, 5 0, 6 0, 7 0, 8 0, 9 0, 10 0, 11 0,
      12 0, 13 0, 14 0, 15 0, 16 0, 17 10, 18 4, 19 0, 20 10, 21 0, 22 3, 23 10 /

    init_s_prime_minus(w)
    / 0 0, 1 9, 2 0, 3 0, 4 0, 5 0, 6 0, 7 0, 8 0, 9 0, 10 0, 11 0,
      12 0, 13 0, 14 0, 15 0, 16 0, 17 10, 18 6, 19 3, 20 0, 21 0, 22 0, 23 0 /
;

* تعریف صحیح پارامترهای init_s_plus و init_s_prime_plus
Parameters init_s_plus(w), init_s_prime_plus(w);
init_s_plus(w) = 0;
init_s_prime_plus(w) = 0;

Scalars
    base_obj_val "Computed from init params"
    init_sum_y_win10 "Sum y for window 10 from init params"
    base_obj_actual "Objective value from solving model"
;

* محاسبه دستی تابع هدف جواب پایه
base_obj_val = sum(h, weights(h) * (init_x(h) + init_y(h)))
             + sum(w, penalty_s_minus(w) * init_s_minus(w))
             + 45 * sum(w, init_s_prime_minus(w));

Display "Base objective from manual calculation:", base_obj_val;

* حل اولیه با cap = base_cap برای بررسی
cap_value = base_cap;
Solve CapacityModel using mip minimizing z;

base_obj_actual = z.l;
Display "Objective from solving model with cap=", base_cap, ":", base_obj_actual;

* محاسبه مقدار مجموع y در پنجره demand_index_to_change برای چک کردن Feasibility
init_sum_y_win10 = sum(h$map_win('10', h), init_y(h));
Display "Sum y for window 10 in base solution:", init_sum_y_win10;

* 4. تحلیل حساسیت (Sensitivity Analysis Loop)
Scalar
    current_cap
    lower_bound
    upper_bound
    base_obj_for_comparison
    break_flag
    is_feasible_basis
    y_sum_win10_temp
    new_obj_val
;

* مقداردهی اولیه
current_cap = base_cap;
lower_bound = current_cap;
upper_bound = current_cap;
base_obj_for_comparison = base_obj_actual;

Display "Starting sensitivity analysis...";
Display "Base objective value for comparison:", base_obj_for_comparison;
Display "Demand_y changed at window: 10";

* حلقه افزایش کران (Up loop)
break_flag = 0;
current_cap = base_cap + 1;

while (current_cap <= MAX_CAP and break_flag = 0,
    cap_value = current_cap;
    
    is_feasible_basis = 1;
    
    y_sum_win10_temp = sum(h$map_win('10', h), init_y(h));
    
    if (y_sum_win10_temp < cap_value - init_s_prime_minus('10'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: y_sum < cap - s_prime_minus at cap =", current_cap;
    );
    
    if (y_sum_win10_temp > cap_value + init_s_prime_plus('10'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: y_sum > cap + s_prime_plus at cap =", current_cap;
    );
    
    if (is_feasible_basis = 1,
        Solve CapacityModel using mip minimizing z;
        new_obj_val = z.l;
        
        if (new_obj_val < base_obj_for_comparison - 0.5,
            Display "Better solution found at cap =", current_cap, "Obj =", new_obj_val;
            break_flag = 1;
        else
            upper_bound = current_cap;
            current_cap = current_cap + 1;
        );
    else
        break_flag = 1;
    );
);

Display "Upper bound loop finished. Upper bound =", upper_bound;

* حلقه کاهش کران (Down loop)
break_flag = 0;
current_cap = base_cap - 1;

while (current_cap >= MIN_CAP and break_flag = 0,
    cap_value = current_cap;
    
    is_feasible_basis = 1;
    
    y_sum_win10_temp = sum(h$map_win('10', h), init_y(h));
    
    if (y_sum_win10_temp < cap_value - init_s_prime_minus('10'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: y_sum < cap - s_prime_minus at cap =", current_cap;
    );
    
    if (y_sum_win10_temp > cap_value + init_s_prime_plus('10'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: y_sum > cap + s_prime_plus at cap =", current_cap;
    );
    
    if (is_feasible_basis = 1,
        Solve CapacityModel using mip minimizing z;
        new_obj_val = z.l;
        
        if (new_obj_val < base_obj_for_comparison - 0.5,
            Display "Better solution found at cap =", current_cap, "Obj =", new_obj_val;
            break_flag = 1;
        else
            lower_bound = current_cap;
            current_cap = current_cap - 1;
        );
    else
        break_flag = 1;
    );
);

Display "Lower bound loop finished. Lower bound =", lower_bound;
Display "Sensitivity Analysis Complete";
Display "✅ بازه‌ای که جواب پایه بهینه باقی می‌ماند:";
Display "از cap =", lower_bound, "تا cap =", upper_bound;