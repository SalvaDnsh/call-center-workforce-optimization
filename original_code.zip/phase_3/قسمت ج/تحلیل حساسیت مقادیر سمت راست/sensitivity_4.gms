* تنظیمات اولیه
Option limrow = 0;
Option limcol = 0;
Option solprint = off;
Option mip = gurobi;
* تنظیم Gap روی صفر برای اطمینان از بهینگی مطلق مثل کد پایتون
Option optcr = 0.0;
Option optca = 0.0;

* 1. تعریف مجموعه‌ها و پارامترها (Sets & Parameters)
Sets
    h "Hours" /0*23/
    w "Windows" /0*23/
;

* نگاشت پنجره‌های زمانی دقیقاً طبق کد پایتون
Set map_win(w, h);
map_win(w, h) = no;

* تعریف دستی پنجره‌ها طبق لیست Python
map_win('0', '18')=yes; map_win('0', '19')=yes; map_win('0', '20')=yes; map_win('0', '22')=yes; map_win('0', '23')=yes; map_win('0', '0')=yes;
map_win('1', '19')=yes; map_win('1', '20')=yes; map_win('1', '21')=yes; map_win('1', '23')=yes; map_win('1', '0')=yes; map_win('1', '1')=yes;
map_win('2', '20')=yes; map_win('2', '21')=yes; map_win('2', '22')=yes; map_win('2', '0')=yes; map_win('2', '1')=yes; map_win('2', '2')=yes;
map_win('3', '21')=yes; map_win('3', '22')=yes; map_win('3', '23')=yes; map_win('3', '1')=yes; map_win('3', '2')=yes; map_win('3', '3')=yes;
map_win('4', '22')=yes; map_win('4', '23')=yes; map_win('4', '0')=yes; map_win('4', '2')=yes; map_win('4', '3')=yes; map_win('4', '4')=yes;
map_win('5', '23')=yes; map_win('5', '0')=yes; map_win('5', '1')=yes; map_win('5', '3')=yes; map_win('5', '4')=yes; map_win('5', '5')=yes;
map_win('6', '0')=yes; map_win('6', '1')=yes; map_win('6', '2')=yes; map_win('6', '4')=yes; map_win('6', '5')=yes; map_win('6', '6')=yes;
map_win('7', '1')=yes; map_win('7', '2')=yes; map_win('7', '3')=yes; map_win('7', '5')=yes; map_win('7', '6')=yes; map_win('7', '7')=yes;
map_win('8', '2')=yes; map_win('8', '3')=yes; map_win('8', '4')=yes; map_win('8', '6')=yes; map_win('8', '7')=yes; map_win('8', '8')=yes;
map_win('9', '3')=yes; map_win('9', '4')=yes; map_win('9', '5')=yes; map_win('9', '7')=yes; map_win('9', '8')=yes; map_win('9', '9')=yes;
map_win('10', '4')=yes; map_win('10', '5')=yes; map_win('10', '6')=yes; map_win('10', '8')=yes; map_win('10', '9')=yes; map_win('10', '10')=yes;
map_win('11', '5')=yes; map_win('11', '6')=yes; map_win('11', '7')=yes; map_win('11', '9')=yes; map_win('11', '10')=yes; map_win('11', '11')=yes;
map_win('12', '6')=yes; map_win('12', '7')=yes; map_win('12', '8')=yes; map_win('12', '10')=yes; map_win('12', '11')=yes; map_win('12', '12')=yes;
map_win('13', '7')=yes; map_win('13', '8')=yes; map_win('13', '9')=yes; map_win('13', '11')=yes; map_win('13', '12')=yes; map_win('13', '13')=yes;
map_win('14', '8')=yes; map_win('14', '9')=yes; map_win('14', '10')=yes; map_win('14', '12')=yes; map_win('14', '13')=yes; map_win('14', '14')=yes;
map_win('15', '9')=yes; map_win('15', '10')=yes; map_win('15', '11')=yes; map_win('15', '13')=yes; map_win('15', '14')=yes; map_win('15', '15')=yes;
map_win('16', '10')=yes; map_win('16', '11')=yes; map_win('16', '12')=yes; map_win('16', '14')=yes; map_win('16', '15')=yes; map_win('16', '16')=yes;
map_win('17', '11')=yes; map_win('17', '12')=yes; map_win('17', '13')=yes; map_win('17', '15')=yes; map_win('17', '16')=yes; map_win('17', '17')=yes;
map_win('18', '12')=yes; map_win('18', '13')=yes; map_win('18', '14')=yes; map_win('18', '16')=yes; map_win('18', '17')=yes; map_win('18', '18')=yes;
map_win('19', '13')=yes; map_win('19', '14')=yes; map_win('19', '15')=yes; map_win('19', '17')=yes; map_win('19', '18')=yes; map_win('19', '19')=yes;
map_win('20', '14')=yes; map_win('20', '15')=yes; map_win('20', '16')=yes; map_win('20', '18')=yes; map_win('20', '19')=yes; map_win('20', '20')=yes;
map_win('21', '15')=yes; map_win('21', '16')=yes; map_win('21', '17')=yes; map_win('21', '19')=yes; map_win('21', '20')=yes; map_win('21', '21')=yes;
map_win('22', '16')=yes; map_win('22', '17')=yes; map_win('22', '18')=yes; map_win('22', '20')=yes; map_win('22', '21')=yes; map_win('22', '22')=yes;
map_win('23', '17')=yes; map_win('23', '18')=yes; map_win('23', '19')=yes; map_win('23', '21')=yes; map_win('23', '22')=yes; map_win('23', '23')=yes;

Parameters
    demands_x(w)
    /
    0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110, 8 140, 9 200, 10 180, 11 180,
    12 240, 13 220, 14 220, 15 230, 16 250, 17 260, 18 230, 19 250, 20 260, 21 250, 22 220, 23 190
    /

    demands_y(w)
    /
    0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90, 8 110, 9 110, 10 110, 11 130,
    12 150, 13 160, 14 120, 15 130, 16 160, 17 180, 18 200, 19 170, 20 140, 21 110, 22 100, 23 90
    /

    weights(h)
    /
    0 189, 1 189, 2 189, 3 180, 4 171, 5 162, 6 153, 7 144, 8 135, 9 126, 10 126, 11 135,
    12 144, 13 153, 14 162, 15 171, 16 180, 17 189, 18 189, 19 189, 20 189, 21 189, 22 189, 23 189
    /

* هزینه پنالتی برای s_minus بر اساس بازه زمانی
    penalty_s_minus(w)
;

* محاسبه مقادیر penalty_s_minus مشابه کد پایتون
penalty_s_minus(w) = 0;
penalty_s_minus(w)$(ord(w)>=8 and ord(w)<=18) = 60; 
penalty_s_minus(w)$(ord(w)>=19 or ord(w)<=7) = 30;   
* 2. متغیرها و معادلات
Variables
    z "Objective function value"
;

Integer Variables
    x(h) "x vars"
    y(h) "y vars"
    s_plus(w)
    s_minus(w)
    s_prime_plus(w)
    s_prime_minus(w)
;

* کران‌های متغیرها
x.lo(h) = 0; y.lo(h) = 0;
s_plus.lo(w) = 0; s_minus.lo(w) = 0;
s_prime_plus.lo(w) = 0; s_prime_minus.lo(w) = 0;

* کران‌های slack (طبق کد: <= 10)
s_minus.up(w) = 10;
s_prime_minus.up(w) = 10;

Equations
    ObjDef "Objective Function"
    CapConstr(h) "x[i] + y[i] <= 100"
    WinCapMax(w) "Sum <= 420"
    WinCapMin(w) "Sum >= 80"
    DemandX_Low(w) "Lower bound for X demand"
    DemandX_High(w) "Upper bound for X demand"
    DemandY_Low(w) "Lower bound for Y demand"
    DemandY_High(w) "Upper bound for Y demand"
    TotalSMinus "Sum s_minus <= 40"
    TotalSPrimeMinus "Sum s_prime_minus <= 30"
;

ObjDef..
    z =e= sum(h, weights(h) * (x(h) + y(h)))
        + sum(w, penalty_s_minus(w) * s_minus(w))
        + 45 * sum(w, s_prime_minus(w));

CapConstr(h)..
    x(h) + y(h) =l= 100;

WinCapMax(w)..
    sum(h$map_win(w, h), x(h) + y(h)) =l= 420;

WinCapMin(w)..
    sum(h$map_win(w, h), x(h) + y(h)) =g= 80;

* پارامتر cap_value باید در حلقه تغییر کند
Parameter cap_value;
cap_value = 50;

DemandX_Low(w)..
    sum(h$map_win(w, h), x(h)) =g= demands_x(w) - s_minus(w)
    + (cap_value - demands_x(w))$(ord(w) = 4);  
DemandX_High(w)..
    sum(h$map_win(w, h), x(h)) =l= demands_x(w) + s_plus(w)
    + (cap_value - demands_x(w))$(ord(w) = 4);  

DemandY_Low(w)..
    sum(h$map_win(w, h), y(h)) =g= demands_y(w) - s_prime_minus(w);

DemandY_High(w)..
    sum(h$map_win(w, h), y(h)) =l= demands_y(w) + s_prime_plus(w);

TotalSMinus..
    sum(w, s_minus(w)) =l= 40;

TotalSPrimeMinus..
    sum(w, s_prime_minus(w)) =l= 30;

Model CapacityModel /all/;

* 3. ذخیره‌سازی جواب پایه (Base Solution Storage)
Parameters
    init_x(h)
    / 0 0, 1 0, 2 0, 3 0, 4 6, 5 33, 6 21, 7 56, 8 57, 9 48, 10 16, 11 43,
      12 47, 13 2, 14 50, 15 71, 16 26, 17 61, 18 40, 19 26, 20 37, 21 29, 22 24, 23 0 /

    init_y(h)
    / 0 0, 1 4, 2 0, 3 13, 4 24, 5 0, 6 29, 7 44, 8 0, 9 29, 10 28, 11 0,
      12 49, 13 38, 14 23, 15 29, 16 31, 17 23, 18 30, 19 24, 20 3, 21 0, 22 13, 23 0 /

    init_s_minus(w)
    / 0 0, 1 3, 2 0, 3 0, 4 0, 5 0, 6 0, 7 0, 8 0, 9 0, 10 0, 11 0,
      12 0, 13 0, 14 0, 15 0, 16 0, 17 10, 18 4, 19 0, 20 10, 21 0, 22 3, 23 10 /

    init_s_prime_minus(w)
    / 0 0, 1 9, 2 0, 3 0, 4 0, 5 0, 6 0, 7 0, 8 0, 9 0, 10 0, 11 0,
      12 0, 13 0, 14 0, 15 0, 16 0, 17 10, 18 6, 19 3, 20 0, 21 0, 22 0, 23 0 /
;

* تعریف و مقداردهی پارامترهای init_s_plus و init_s_prime_plus
Parameters init_s_plus(w), init_s_prime_plus(w);
init_s_plus(w) = 0;
init_s_prime_plus(w) = 0;

Scalars
    base_obj_val "Computed from init params"
    init_sum_x_win3 "Sum x for window 3 from init params"
    base_obj_actual
    current_cap
    lower_bound
    upper_bound
    base_obj_for_comparison
    break_flag
    is_feasible_basis
;

* محاسبه دستی تابع هدف جواب پایه
base_obj_val = sum(h, weights(h) * (init_x(h) + init_y(h)))
             + sum(w, penalty_s_minus(w) * init_s_minus(w))
             + 45 * sum(w, init_s_prime_minus(w));

Display "Base objective from manual calculation:", base_obj_val;

* حل اولیه با cap = 50
cap_value = 50;
Solve CapacityModel using mip minimizing z;

base_obj_actual = z.l;
Display "Base objective from solving model with cap=50:", base_obj_actual;

* محاسبه مقدار مجموع x در پنجره 3 برای چک کردن Feasibility
init_sum_x_win3 = sum(h$map_win('3', h), init_x(h));
Display "Sum x for window 3 in base solution:", init_sum_x_win3;

* 4. تحلیل حساسیت (Sensitivity Analysis Loop)
* مقداردهی اولیه
current_cap = 50;
lower_bound = current_cap;
upper_bound = current_cap;
base_obj_for_comparison = base_obj_actual;

Display "Starting sensitivity analysis...";
Display "Base objective value for comparison:", base_obj_for_comparison;

* حلقه افزایش کران (Up loop)
break_flag = 0;
current_cap = 51;

while (current_cap <= 200 and break_flag = 0,
    cap_value = current_cap;
    
    is_feasible_basis = 1;
    
    if (init_sum_x_win3 < cap_value - init_s_minus('3'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: x_sum < cap - s_minus";
    );
    
    if (init_sum_x_win3 > cap_value + init_s_plus('3'),
        is_feasible_basis = 0;
        Display "Base solution infeasible: x_sum > cap + s_plus";
    );
    
    if (is_feasible_basis = 1,
        Solve CapacityModel using mip minimizing z;
        
        if (z.l < base_obj_for_comparison - 0.5,
            Display "Better solution found at cap =", current_cap, "Obj =", z.l;
            break_flag = 1;
        else
            upper_bound = current_cap;
            current_cap = current_cap + 1;
        );
    else
        Display "Base solution infeasible at cap =", current_cap;
        break_flag = 1;
    );
);

Display "Upper bound loop finished. Upper bound =", upper_bound;

* حلقه کاهش کران (Down loop)
break_flag = 0;
current_cap = 49;

while (current_cap >= 0 and break_flag = 0,
    cap_value = current_cap;
    
    is_feasible_basis = 1;
    
    if (init_sum_x_win3 < cap_value - init_s_minus('3'),
        is_feasible_basis = 0;
    );
    
    if (init_sum_x_win3 > cap_value + init_s_plus('3'),
        is_feasible_basis = 0;
    );
    
    if (is_feasible_basis = 1,
        Solve CapacityModel using mip minimizing z;
        
        if (z.l < base_obj_for_comparison - 0.5,
            Display "Better solution found at cap =", current_cap, "Obj =", z.l;
            break_flag = 1;
        else
            lower_bound = current_cap;
            current_cap = current_cap - 1;
        );
    else
        Display "Base solution infeasible at cap =", current_cap;
        break_flag = 1;
    );
);

Display "Lower bound loop finished. Lower bound =", lower_bound;
Display "Sensitivity Analysis Complete";
Display "Sensitivity Range for cap_value at window 3:";
Display "From", lower_bound, "to", upper_bound;
Display "Base objective value:", base_obj_for_comparison;