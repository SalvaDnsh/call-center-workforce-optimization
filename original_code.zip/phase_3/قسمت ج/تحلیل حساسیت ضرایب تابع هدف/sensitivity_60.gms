$title Sensitivity Analysis for s_minus Coefficient (Day Penalty 60)

Option optcr = 0;
Option mip = cbc;

* ---------------- 1. تعریف مجموعه‌ها ----------------
Set H /0*23/;
Alias(H, J);

* تعریف زیرمجموعه ساعات روز (7 تا 17 طبق کد پایتون)
Set DayHours(H);
DayHours(H) = yes$(H.val >= 7 and H.val <= 17);

* تعریف پنجره‌ها (همان منطق قبلی)
Set mapW(H, J);
mapW(H, J) = yes$(mod(24 + H.val - J.val, 24) <> 3 and mod(24 + H.val - J.val, 24) <= 6);

* ---------------- 2. پارامترها و داده‌ها ----------------
Parameter demands_x(H) /
0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110, 8 140, 9 200, 10 180, 11 180,
12 240, 13 220, 14 220, 15 230, 16 250, 17 260, 18 230, 19 250, 20 260, 21 250, 22 220, 23 190
/;

Parameter demands_y(H) /
0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90, 8 110, 9 110, 10 110, 11 130,
12 150, 13 160, 14 120, 15 130, 16 160, 17 180, 18 200, 19 170, 20 140, 21 110, 22 100, 23 90
/;

* ضرایب ثابت X و Y (طبق لیست weights در کد پایتون شما)
Parameter fixed_weights(H) /
0 189, 1 189, 2 189, 3 180, 4 171, 5 162, 6 153, 7 144, 8 135, 9 126, 10 126, 11 135,
12 144, 13 153, 14 162, 15 171, 16 180, 17 189, 18 189, 19 189, 20 189, 21 189, 22 189, 23 189
/;

* مقادیر دستی s_minus از دیکشنری manual_solution
Parameter manual_s_minus(H) /
0 0.0, 1 2.0, 2 0.0, 3 0.0, 4 0.0, 
5 0.0, 6 0.0, 7 0.0, 8 0.0, 9 0.0, 
10 0.0, 11 0.0, 12 0.0, 13 0.0, 14 0.0, 
15 0.0, 16 0.0, 17 10.0, 18 4.0, 19 0.0, 
20 10.0, 21 0.0, 22 4.0, 23 10.0
/;

* پارامتر متغیر برای ضریب جریمه ساعات روز (پایه 60)
Parameter penalty_day(H);
penalty_day(H)$DayHours(H) = 60;

* ---------------- 3. متغیرها ----------------
Integer Variables 
    x(H), y(H)
    s_plus(H), s_minus(H)
    sp_plus(H), sp_minus(H);

* کران بالا برای جلوگیری از خطا
x.up(H)=10000; y.up(H)=10000;
s_plus.up(H)=10000; s_minus.up(H)=10000;
sp_plus.up(H)=10000; sp_minus.up(H)=10000;

Free Variable Z;

* ---------------- 4. معادلات ----------------
Equations
    Eq_Obj, Eq_Cap(H)
    Eq_WinUpper(H), Eq_WinLower(H)
    Eq_dx_l(H), Eq_dx_u(H)
    Eq_dy_l(H), Eq_dy_u(H)
    Eq_s_minus_cap(H), Eq_sp_minus_cap(H)
    Eq_total_s_minus, Eq_total_sp_minus;

* تابع هدف:
* 1. هزینه X و Y (ثابت)
* 2. هزینه s_minus در ساعات روز (متغیر، با استفاده از penalty_day)
* 3. هزینه s_minus در ساعات شب (ثابت 30)
* 4. هزینه sp_minus (ثابت 45)
Eq_Obj.. Z =e= sum(H, fixed_weights(H)*x(H) + fixed_weights(H)*y(H))
             + sum(H$DayHours(H), penalty_day(H) * s_minus(H))
             + 30 * sum(H$(not DayHours(H)), s_minus(H))
             + 45 * sum(H, sp_minus(H));

Eq_Cap(H).. x(H) + y(H) =l= 100;

Eq_WinUpper(H).. sum(J$mapW(H,J), x(J) + y(J)) =l= 420;
Eq_WinLower(H).. sum(J$mapW(H,J), x(J) + y(J)) =g= 80;

Eq_dx_l(H).. sum(J$mapW(H,J), x(J)) =g= demands_x(H) - s_minus(H);
Eq_dx_u(H).. sum(J$mapW(H,J), x(J)) =l= demands_x(H) + s_plus(H);

Eq_dy_l(H).. sum(J$mapW(H,J), y(J)) =g= demands_y(H) - sp_minus(H);
Eq_dy_u(H).. sum(J$mapW(H,J), y(J)) =l= demands_y(H) + sp_plus(H);

Eq_s_minus_cap(H).. s_minus(H) =l= 10;
Eq_sp_minus_cap(H).. sp_minus(H) =l= 10;

Eq_total_s_minus.. sum(H, s_minus(H)) =l= 40;
Eq_total_sp_minus.. sum(H, sp_minus(H)) =l= 30;

Model sensitivity_s_minus /all/;

* ---------------- 5. تحلیل حساسیت (اصلاح شده) ----------------
Scalar index_change /17/;
Scalar base_weight /60/;
Scalar base_obj;
Scalar current_weight;
Scalar delta_weight;
Scalar expected_obj;
Scalar s_minus_val_base;
Scalar upper_bound, lower_bound;
Scalar iter_count, found_break;

* خواندن مقدار متغیر از جواب دستی
s_minus_val_base = manual_s_minus('17');

* 1. حل پایه
penalty_day('17') = base_weight;
Solve sensitivity_s_minus using mip minimizing Z;
base_obj = Z.l;

Display "Base Obj:", base_obj, "Manual s_minus[17]:", s_minus_val_base;

* ---- کران بالا ----
current_weight = base_weight + 1;
iter_count = 0;
found_break = 0;
upper_bound = base_weight;

while((iter_count < 50) and (found_break = 0),
    penalty_day('17') = current_weight;
    Solve sensitivity_s_minus using mip minimizing Z;
    
    delta_weight = current_weight - base_weight;
    expected_obj = base_obj + (delta_weight * s_minus_val_base);
    
    if (Z.l < expected_obj - 1e-5,
        found_break = 1;
        Display "Break Found (Upper) at weight:", current_weight, "Obj:", Z.l, "Expected:", expected_obj;
    else
        upper_bound = current_weight;
        current_weight = current_weight + 1;
    );
    iter_count = iter_count + 1;
);

* ---- کران پایین ----
current_weight = base_weight - 1;
iter_count = 0;
found_break = 0;
lower_bound = base_weight;

while((iter_count < 50) and (current_weight > 0) and (found_break = 0),
    penalty_day('17') = current_weight;
    Solve sensitivity_s_minus using mip minimizing Z;
    
    delta_weight = current_weight - base_weight;
    expected_obj = base_obj + (delta_weight * s_minus_val_base);
    
    if (Z.l < expected_obj - 1e-5,
        found_break = 1;
        Display "Break Found (Lower) at weight:", current_weight, "Obj:", Z.l, "Expected:", expected_obj;
    else
        lower_bound = current_weight;
        current_weight = current_weight - 1;
    );
    iter_count = iter_count + 1;
);

Display "--- RESULTS for s_minus[17] ---";
Display lower_bound, upper_bound;