$title Sensitivity Analysis for Objective Coefficients

Option optcr = 0; 
Option mip = cbc; 
* توجه: در صورت نیاز می‌توانید نام حل‌گر را به cplex یا gurobi تغییر دهید

* ---------------- 1. تعریف مجموعه‌ها ----------------
Set H /0*23/;
Alias(H, J);

* تعریف ساختار پنجره‌ها: 
* دقیقاً معادل لیست پنجره‌های پایتون شما (۶ ساعت قبل و خودش، با حذف ۳ ساعت قبل)
Set mapW(H, J);
mapW(H, J) = yes$(mod(24 + H.val - J.val, 24) <> 3 and mod(24 + H.val - J.val, 24) <= 6);

* ---------------- 2. پارامترها و داده‌ها ----------------
Parameter demands_x(H) /
0 120, 1 95, 2 90, 3 50, 4 30, 5 30, 6 60, 7 110, 8 140, 9 200, 10 180, 11 180,
12 240, 13 220, 14 220, 15 230, 16 250, 17 260, 18 230, 19 250, 20 260, 21 250, 22 220, 23 190
/;

Parameter demands_y(H) /
0 70, 1 40, 2 20, 3 30, 4 50, 5 40, 6 40, 7 90, 8 110, 9 110, 10 110, 11 130,
12 150, 13 160, 14 120, 15 130, 16 160, 17 180, 18 200, 19 170, 20 140, 21 110, 22 100, 23 90
/;

Parameter base_weights_x(H) /
0 189, 1 189, 2 189, 3 180, 4 171, 5 162, 6 153, 7 144, 8 135, 9 126, 10 126, 11 135,
12 144, 13 153, 14 162, 15 171, 16 180, 17 189, 18 189, 19 189, 20 189, 21 189, 22 189, 23 189
/;

Parameter base_weights_y(H) /
0 189, 1 189, 2 189, 3 180, 4 171, 5 162, 6 153, 7 144, 8 135, 9 126, 10 126, 11 135,
12 144, 13 153, 14 162, 15 171, 16 180, 17 189, 18 189, 19 189, 20 189, 21 189, 22 189, 23 189
/;

* جواب دستی (برای مقایسه و پایه محاسبات)
Parameter manual_x(H) /
0 0, 1 0, 2 0, 3 0, 4 12, 5 25, 6 23, 7 62, 8 43, 9 58, 10 19, 11 32,
12 61, 13 0, 14 39, 15 82, 16 18, 17 57, 18 51, 19 21, 20 39, 21 33, 22 18, 23 0
/;

Parameter wx(H), wy(H);
wx(H) = base_weights_x(H);
wy(H) = base_weights_y(H);

* ---------------- 3. متغیرها ----------------
Integer Variables 
    x(H), y(H)
    s_plus(H), s_minus(H)
    sp_plus(H), sp_minus(H);

* قرار دادن یک کران بالای بزرگ برای جلوگیری از خطای پیش‌فرض در گمز
x.up(H)=10000; y.up(H)=10000;
s_plus.up(H)=10000; s_minus.up(H)=10000;
sp_plus.up(H)=10000; sp_minus.up(H)=10000;

Free Variable Z;

* ---------------- 4. محدودیت‌ها (معادلات) ----------------
Equations
    Eq_Obj, Eq_Cap(H)
    Eq_WinUpper(H), Eq_WinLower(H)
    Eq_dx_l(H), Eq_dx_u(H)
    Eq_dy_l(H), Eq_dy_u(H)
    Eq_s_minus_cap(H), Eq_sp_minus_cap(H)
    Eq_total_s_minus, Eq_total_sp_minus;

Eq_Obj.. Z =e= sum(H, wx(H)*x(H) + wy(H)*y(H)) 
             + 60*sum(H$(H.val >= 7 and H.val <= 17), s_minus(H))
             + 30*sum(H$(H.val < 7 or H.val > 17), s_minus(H))
             + 45*sum(H, sp_minus(H));

Eq_Cap(H).. x(H) + y(H) =l= 100;

Eq_WinUpper(H).. sum(J$mapW(H,J), x(J) + y(J)) =l= 420;
Eq_WinLower(H).. sum(J$mapW(H,J), x(J) + y(J)) =g= 80;

Eq_dx_l(H).. sum(J$mapW(H,J), x(J)) =g= demands_x(H) - s_minus(H);
Eq_dx_u(H).. sum(J$mapW(H,J), x(J)) =l= demands_x(H) + s_plus(H);

Eq_dy_l(H).. sum(J$mapW(H,J), y(J)) =g= demands_y(H) - sp_minus(H);
Eq_dy_u(H).. sum(J$mapW(H,J), y(J)) =l= demands_y(H) + sp_plus(H);

Eq_s_minus_cap(H).. s_minus(H) =l= 10;
Eq_sp_minus_cap(H).. sp_minus(H) =l= 10;

Eq_total_s_minus.. sum(H, s_minus(H)) =l= 40;
Eq_total_sp_minus.. sum(H, sp_minus(H)) =l= 30;

Model sensitivity_model /all/;

* ---------------- 5. حلقه تحلیل حساسیت ----------------
* پارامترهای کنترل حلقه
Scalar base_weight / 171 /;
Scalar base_obj;
Scalar current_weight;
Scalar delta_weight;
Scalar expected_obj;
Scalar upper_bound;
Scalar lower_bound;
Scalar iter_count;
Scalar x_val_base;
Scalar found_break;

x_val_base = manual_x('4');

* گام اول: حل مدل پایه برای بدست آوردن تابع هدف
wx('4') = base_weight;
Solve sensitivity_model using mip minimizing Z;
base_obj = Z.l;

Display "Base objective is:", base_obj, x_val_base;

* --- پیدا کردن کران بالا ---
current_weight = base_weight + 1;
iter_count = 0;
found_break = 0;
upper_bound = base_weight;

while((iter_count < 50) and (found_break = 0),
    wx('4') = current_weight;
    Solve sensitivity_model using mip minimizing Z;
    
    delta_weight = current_weight - base_weight;
    expected_obj = base_obj + (delta_weight * x_val_base);
    
    if (Z.l < expected_obj - 1e-5,
        found_break = 1;
    else
        upper_bound = current_weight;
        current_weight = current_weight + 1;
    );
    iter_count = iter_count + 1;
);

* --- پیدا کردن کران پایین ---
current_weight = base_weight - 1;
iter_count = 0;
found_break = 0;
lower_bound = base_weight;

while((iter_count < 50) and (current_weight > 0) and (found_break = 0),
    wx('4') = current_weight;
    Solve sensitivity_model using mip minimizing Z;
    
    delta_weight = current_weight - base_weight;
    expected_obj = base_obj + (delta_weight * x_val_base);
    
    if (Z.l < expected_obj - 1e-5,
        found_break = 1;
    else
        lower_bound = current_weight;
        current_weight = current_weight - 1;
    );
    iter_count = iter_count + 1;
);

* چاپ نتایج نهایی کران‌ها
Display "--- RESULTS ---";
Display upper_bound, lower_bound;

* ---------------- 6. نمایش متغیرهای تغییر یافته ----------------
* مقایسه جواب حل‌گر در آخرین تکرار با جواب دستی
Parameter diff_x(H);
* فقط متغیرهایی که تفاوتشان بزرگتر از یک مقدار بسیار کوچک است ذخیره می‌شوند
diff_x(H)$(abs(x.l(H) - manual_x(H)) > 1e-6) = x.l(H) - manual_x(H);

Display "--- Changed Variables (Difference from manual) ---";
Display diff_x;