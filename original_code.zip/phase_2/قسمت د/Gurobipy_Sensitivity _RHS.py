# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from gurobipy import *

# ---------------- تابع حل با تغییر محدودیت کلی ≤ cap_value ----------------
def solve_with_cap_gurobi(cap_value):
    try:
        H = range(24)

        model = Model("window_capacity_model")
        model.setParam("OutputFlag", 0)

        # ---------------- متغیرها ----------------
        x = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="x")
        y = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="y")

        s_plus  = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_plus")
        s_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_minus")

        s_prime_plus  = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_plus")
        s_prime_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_minus")

        # ---------------- محدودیت ظرفیت هر ساعت ----------------
        model.addConstrs(x[i] + y[i] <= 100 for i in H)

        # ---------------- پنجره‌ها ----------------
        windows = [
            [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
            [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
            [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
            [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
            [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
            [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
        ]

        # ---------------- محدودیت ظرفیت پنجره‌ها ----------------
        model.addConstrs(
            quicksum(x[j] + y[j] for j in windows[k]) <= 420
            for k in range(len(windows))
        )

        model.addConstrs(
            quicksum(x[j] + y[j] for j in windows[k]) >= 80
            for k in range(len(windows))
        )

        # ---------------- محدودیت‌های تقاضا ----------------
        demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
        demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

        model.addConstrs(
            quicksum(x[j] for j in windows[k]) >= demands_x[k] - s_minus[k]
            for k in range(len(windows))
        )
        model.addConstrs(
            quicksum(x[j] for j in windows[k]) <= demands_x[k] + s_plus[k]
            for k in range(len(windows))
        )

        model.addConstrs(
            quicksum(y[j] for j in windows[k]) >= demands_y[k] - s_prime_minus[k]
            for k in range(len(windows))
        )
        model.addConstrs(
            quicksum(y[j] for j in windows[k]) <= demands_y[k] + s_prime_plus[k]
            for k in range(len(windows))
        )

        # ---------------- محدودیت‌های ≤10 ----------------
        model.addConstrs(s_minus[i] <= 10 for i in H)
        model.addConstrs(s_prime_minus[i] <= 10 for i in H)

        # ---------------- محدودیت‌های کلی ----------------
        model.addConstr(quicksum(s_minus[i] for i in H) <= 40)
        model.addConstr(quicksum(s_prime_minus[i] for i in H) <= cap_value)

        # ---------------- تابع هدف ----------------
        weights = [189,189,189,180,171,162,153,144,135,126,126,135,
                   144,153,162,171,180,189,189,189,189,189,189,189]

        obj = quicksum(weights[i] * (x[i] + y[i]) for i in H)
        obj += 60 * quicksum(s_minus[i] for i in range(7,18))
        obj += 30 * quicksum(s_minus[i] for i in range(18,24))
        obj += 30 * quicksum(s_minus[i] for i in range(0,7))
        obj += 45 * quicksum(s_prime_minus[i] for i in H)

        model.setObjective(obj, GRB.MINIMIZE)

        # ---------------- حل مدل ----------------
        model.optimize()

        if model.Status == GRB.OPTIMAL:
            print(f"cap_value = {cap_value:>3}  --> Objective = {model.ObjVal:.2f}")
            return model.ObjVal
        else:
            print(f"cap_value = {cap_value:>3}  --> Objective = None (not optimal)")
            return None

    except Exception as e:
        print(f"cap_value = {cap_value:>3}  --> Error / Infeasible")
        return None


# ---------------- رسم نمودار تغییر تابع هدف ----------------
base_cap = 30
caps = list(range(base_cap - 20, base_cap + 21))  # از 10 تا 50

objectives = [solve_with_cap_gurobi(c) for c in caps]

plt.figure(figsize=(8,5))
plt.plot(caps, objectives, marker='o')
plt.xlabel("cap_value")
plt.ylabel("Objective value")
plt.title("taaghirate tabe hadaf  (Gurobi)")
plt.grid(True)
plt.show()
