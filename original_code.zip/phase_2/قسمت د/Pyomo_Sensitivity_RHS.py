# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from pyomo.environ import *
from pyomo.opt import SolverFactory


def solve_with_cap(cap_value):
    H = range(24)
    model = ConcreteModel()
    model.H = Set(initialize=H)


    model.x = Var(model.H, domain=NonNegativeIntegers)
    model.y = Var(model.H, domain=NonNegativeIntegers)
    model.s_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_minus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_minus = Var(model.H, domain=NonNegativeIntegers)


    model.cap_constraint = Constraint(model.H, rule=lambda m,i: m.x[i] + m.y[i] <= 100)


    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]


    model.win_cap = Constraint(range(len(windows)), rule=lambda m,k: sum(m.x[j]+m.y[j] for j in windows[k]) <= 420)
    model.win_min = Constraint(range(len(windows)), rule=lambda m,k: sum(m.x[j]+m.y[j] for j in windows[k]) >= 80)


    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    model.demand_x_low  = Constraint(range(len(windows)), rule=lambda m,k: sum(m.x[j] for j in windows[k]) >= demands_x[k] - m.s_minus[k])
    model.demand_x_high = Constraint(range(len(windows)), rule=lambda m,k: sum(m.x[j] for j in windows[k]) <= demands_x[k] + m.s_plus[k])
    model.demand_y_low  = Constraint(range(len(windows)), rule=lambda m,k: sum(m.y[j] for j in windows[k]) >= demands_y[k] - m.s_prime_minus[k])
    model.demand_y_high = Constraint(range(len(windows)), rule=lambda m,k: sum(m.y[j] for j in windows[k]) <= demands_y[k] + m.s_prime_plus[k])


    model.s_bounds_minus = Constraint(model.H, rule=lambda m,i: m.s_minus[i] <= 10)
    model.s_bounds_prime = Constraint(model.H, rule=lambda m,i: m.s_prime_minus[i] <= 10)


    model.total_s_minus       = Constraint(expr=sum(model.s_minus[i] for i in H) <= cap_value)
    model.total_s_prime_minus = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)


    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    obj_expr  = sum(weights[i]*(model.x[i]+model.y[i]) for i in H)
    obj_expr += 60*sum(model.s_minus[i] for i in range(7,18))
    obj_expr += 30*sum(model.s_minus[i] for i in range(18,24))
    obj_expr += 30*sum(model.s_minus[i] for i in range(0,7))
    obj_expr += 45*sum(model.s_prime_minus[i] for i in H)

    model.obj = Objective(expr=obj_expr, sense=minimize)


    opt = SolverFactory("cbc")
    opt.solve(model, tee=False)

    return value(model.obj)


#رسم نمودار
base_cap = 40
caps = list(range(base_cap-30, base_cap+31))  # از 10 تا 70
objectives = [solve_with_cap(c) for c in caps]

plt.figure(figsize=(8,5))
plt.plot(caps, objectives, marker='o')
plt.xlabel("value")
plt.ylabel("Objective value")
plt.title("taaghirate tabe hadaf")
plt.grid(True)
plt.show()


