# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from pyomo.environ import *
from pyomo.opt import SolverFactory

# ---------------- تابع حل مدل ----------------
def solve_with_c45(c45_value):
    H = range(24)
    model = ConcreteModel()
    model.H = Set(initialize=H)

    # ---------- متغیرها ----------
    model.x = Var(model.H, domain=NonNegativeIntegers)
    model.y = Var(model.H, domain=NonNegativeIntegers)
    model.s_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_minus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_minus = Var(model.H, domain=NonNegativeIntegers)

    # ---------- پارامتر ضریب ----------
    model.c45 = Param(initialize=c45_value, mutable=True)

    # ---------- محدودیت ظرفیت ----------
    model.cap = Constraint(model.H, rule=lambda m,i: m.x[i] + m.y[i] <= 100)

    # ---------- پنجره‌ها ----------
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]

    model.win_up = Constraint(range(24),
        rule=lambda m,k: sum(m.x[j] + m.y[j] for j in windows[k]) <= 420)
    model.win_lo = Constraint(range(24),
        rule=lambda m,k: sum(m.x[j] + m.y[j] for j in windows[k]) >= 80)

    # ---------- تقاضا ----------
    dx = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    dy = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    model.dx_l = Constraint(range(24),
        rule=lambda m,i: sum(m.x[j] for j in windows[i]) >= dx[i] - m.s_minus[i])
    model.dx_u = Constraint(range(24),
        rule=lambda m,i: sum(m.x[j] for j in windows[i]) <= dx[i] + m.s_plus[i])

    model.dy_l = Constraint(range(24),
        rule=lambda m,i: sum(m.y[j] for j in windows[i]) >= dy[i] - m.s_prime_minus[i])
    model.dy_u = Constraint(range(24),
        rule=lambda m,i: sum(m.y[j] for j in windows[i]) <= dy[i] + m.s_prime_plus[i])

    # ---------- کران slack ----------
    model.s_cap = Constraint(model.H, rule=lambda m,i: m.s_minus[i] <= 10)
    model.s_p_cap = Constraint(model.H, rule=lambda m,i: m.s_prime_minus[i] <= 10)

    model.sum_s = Constraint(expr=sum(model.s_minus[i] for i in H) <= 40)
    model.sum_sp = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)

    # ---------- تابع هدف ----------
    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    model.obj = Objective(
        expr=
        sum(weights[i]*(model.x[i] + model.y[i]) for i in H)
        + 60*sum(model.s_minus[i] for i in range(7,18))
        + 30*sum(model.s_minus[i] for i in range(18,24))
        + 30*sum(model.s_minus[i] for i in range(0,7))
        + model.c45 * sum(model.s_prime_minus[i] for i in H),
        sense=minimize
    )

    SolverFactory("cbc").solve(model, tee=False)
    return value(model.obj)

# ---------------- رسم نمودار ----------------
base_c45 = 45
c45_values = list(range(max(0, base_c45-20), base_c45+21))
obj_values = [solve_with_c45(c) for c in c45_values]

plt.figure(figsize=(8,5))
plt.plot(c45_values, obj_values, marker='o')
plt.axvline(base_c45, linestyle='--')
plt.xlabel("Coefficient of s'_minus (c45)")
plt.ylabel("Objective Value")
plt.title("Sensitivity Analysis of Objective Function w.r.t c45")
plt.grid(True)
plt.show()
