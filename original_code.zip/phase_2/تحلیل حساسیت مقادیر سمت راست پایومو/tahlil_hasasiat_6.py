# -*- coding: utf-8 -*-
from pyomo.environ import *

#تابع مربوط به حل مدل
def solve_with_cap(cap_value, index_to_change):
    H = range(24)
    model = ConcreteModel()

    model.x = Var(H, domain=NonNegativeIntegers)
    model.y = Var(H, domain=NonNegativeIntegers)
    model.s_plus = Var(H, domain=NonNegativeIntegers)
    model.s_minus = Var(H, domain=NonNegativeIntegers)
    model.s_prime_plus = Var(H, domain=NonNegativeIntegers)
    model.s_prime_minus = Var(H, domain=NonNegativeIntegers)

    model.cap_constraint = Constraint(H, rule=lambda m, i: m.x[i] + m.y[i] <= 100)

    windows = [
        [18,19,20,22,23,0],[19,20,21,23,0,1],[20,21,22,0,1,2],[21,22,23,1,2,3],
        [22,23,0,2,3,4],[23,0,1,3,4,5],[0,1,2,4,5,6],[1,2,3,5,6,7],
        [2,3,4,6,7,8],[3,4,5,7,8,9],[4,5,6,8,9,10],[5,6,7,9,10,11],
        [6,7,8,10,11,12],[7,8,9,11,12,13],[8,9,10,12,13,14],[9,10,11,13,14,15],
        [10,11,12,14,15,16],[11,12,13,15,16,17],[12,13,14,16,17,18],
        [13,14,15,17,18,19],[14,15,16,18,19,20],[15,16,17,19,20,21],
        [16,17,18,20,21,22],[17,18,19,21,22,23]
    ]

    model.win_upper = Constraint(range(24),
        rule=lambda m, w: sum(m.x[j] + m.y[j] for j in windows[w]) <= 420)

    model.win_lower = Constraint(range(24),
        rule=lambda m, w: sum(m.x[j] + m.y[j] for j in windows[w]) >= 80)

    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,
                 240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,
                 150,160,120,130,160,180,200,170,140,110,100,90]

    model.demand_x_low = Constraint(range(24),
        rule=lambda m, i: sum(m.x[j] for j in windows[i]) >= demands_x[i] - m.s_minus[i])
    model.demand_x_high = Constraint(range(24),
        rule=lambda m, i: sum(m.x[j] for j in windows[i]) <= demands_x[i] + m.s_plus[i])

    model.demand_y_low = Constraint(range(24),
        rule=lambda m, i: sum(m.y[j] for j in windows[i]) >= demands_y[i] - m.s_prime_minus[i])
    model.demand_y_high = Constraint(range(24),
        rule=lambda m, i: sum(m.y[j] for j in windows[i]) <= demands_y[i] + m.s_prime_plus[i])

    model.s_minus_cap = Constraint(H,
        rule=lambda m, i: m.s_minus[i] <= (cap_value if i == index_to_change else 10))
    model.s_prime_minus_cap = Constraint(H,
        rule=lambda m, i: m.s_prime_minus[i] <= 10)

    model.total_s_minus = Constraint(expr=sum(model.s_minus[i] for i in H) <= 40)
    model.total_s_prime_minus = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)

    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    model.obj = Objective(
        expr=sum(weights[i]*(model.x[i]+model.y[i]) for i in H)
             + 60*sum(model.s_minus[i] for i in range(7,18))
             + 30*sum(model.s_minus[i] for i in list(range(18,24))+list(range(0,7)))
             + 45*sum(model.s_prime_minus[i] for i in H),
        sense=minimize)

    SolverFactory("cbc").solve(model, tee=False)

    sol = {}
    for i in H:
        sol[f"x[{i}]"] = model.x[i].value
        sol[f"y[{i}]"] = model.y[i].value
        sol[f"s_minus[{i}]"] = model.s_minus[i].value
        sol[f"s_plus[{i}]"] = model.s_plus[i].value
        sol[f"s_prime_minus[{i}]"] = model.s_prime_minus[i].value
        sol[f"s_prime_plus[{i}]"] = model.s_prime_plus[i].value
    return sol


#تابع چک کردن موجه بودن
def is_feasible(sol, cap_value, index_to_change):
    H = range(24)

    if sum(sol[f"s_minus[{i}]"] for i in H) > 40: return False
    if sum(sol[f"s_prime_minus[{i}]"] for i in H) > 30: return False

    for i in H:
        if sol[f"x[{i}]"] + sol[f"y[{i}]"] > 100: return False
        if sol[f"s_minus[{i}]"] > (cap_value if i == index_to_change else 10): return False
        if sol[f"s_prime_minus[{i}]"] > 10: return False

    windows = [
        [18,19,20,22,23,0],[19,20,21,23,0,1],[20,21,22,0,1,2],[21,22,23,1,2,3],
        [22,23,0,2,3,4],[23,0,1,3,4,5],[0,1,2,4,5,6],[1,2,3,5,6,7],
        [2,3,4,6,7,8],[3,4,5,7,8,9],[4,5,6,8,9,10],[5,6,7,9,10,11],
        [6,7,8,10,11,12],[7,8,9,11,12,13],[8,9,10,12,13,14],[9,10,11,13,14,15],
        [10,11,12,14,15,16],[11,12,13,15,16,17],[12,13,14,16,17,18],
        [13,14,15,17,18,19],[14,15,16,18,19,20],[15,16,17,19,20,21],
        [16,17,18,20,21,22],[17,18,19,21,22,23]
    ]

    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,
                 240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,
                 150,160,120,130,160,180,200,170,140,110,100,90]

    for i in H:
        wx = sum(sol[f"x[{j}]"] for j in windows[i])
        wy = sum(sol[f"y[{j}]"] for j in windows[i])
        if wx < demands_x[i] - sol[f"s_minus[{i}]"]: return False
        if wy < demands_y[i] - sol[f"s_prime_minus[{i}]"]: return False

    return True


#تابع محاسبه تابع هدف
def compute_objective(sol):
    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]
    H = range(24)
    val = sum(weights[i]*(sol[f"x[{i}]"]+sol[f"y[{i}]"]) for i in H)
    val += 60*sum(sol[f"s_minus[{i}]"] for i in range(7,18))
    val += 30*sum(sol[f"s_minus[{i}]"] for i in list(range(18,24))+list(range(0,7)))
    val += 45*sum(sol[f"s_prime_minus[{i}]"] for i in H)
    return val


#جواب اولیه ای که تحلیل حساسیت را روی آن انجام میدهیم و در فایل وورد هم آورده شده
initial_sol = {
    f"x[{i}]": v for i, v in enumerate(
        [0,0,0,0,6,33,21,56,57,48,16,43,47,2,50,71,26,61,40,26,37,29,24,0])
}
initial_sol.update({
    f"y[{i}]": v for i, v in enumerate(
        [0,4,0,13,24,0,29,44,0,29,28,0,49,38,23,29,31,23,30,24,3,0,13,0])
})
initial_sol.update({
    f"s_minus[{i}]": v for i, v in enumerate(
        [0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,4,0,10,0,3,10])
})
initial_sol.update({
    f"s_prime_minus[{i}]": v for i, v in enumerate(
        [0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,6,3,0,0,0,0])
})
initial_sol.update({f"s_plus[{i}]": v for i,v in enumerate(
    [7,0,0,3,0,9,0,0,0,0,1,37,0,33,0,0,3,0,0,0,0,0,0,0])
})
initial_sol.update({f"s_prime_plus[{i}]": 0 for i,v in enumerate(
    [0,0,0,0,0,1,17,0,0,0,0,0,0,0,47,17,0,0,0,0,0,0,0,0])
})

#بخش تحلیل حساسیت
index_to_change = 20
base_cap = 10

base_sol = initial_sol
base_obj = compute_objective(base_sol)
print("✅ شروع از جواب اولیه | objective =", base_obj)

#کران بالا
cap = base_cap + 1
while cap <= 200:
    if not is_feasible(base_sol, cap, index_to_change):
        print(f"\n❌ infeasible در cap = {cap}")
        break
    new_sol = solve_with_cap(cap, index_to_change)
    new_obj = compute_objective(new_sol)
    if new_obj < base_obj - 1e-6:
        print(f"\n⭐ بهبود در cap = {cap} | objective = {new_obj}")
        break
    cap += 1

#کران پایین
cap = base_cap - 1
while cap >= 0:
    if not is_feasible(base_sol, cap, index_to_change):
        print(f"\n❌ infeasible در cap = {cap}")
        break
    new_sol = solve_with_cap(cap, index_to_change)
    new_obj = compute_objective(new_sol)
    if new_obj < base_obj - 1e-6:
        print(f"\n⭐ بهبود در cap = {cap} | objective = {new_obj}")
        break
    cap -= 1

print("\n✅ تحلیل حساسیت کامل شد")
