# -*- coding: utf-8 -*-
from pyomo.environ import *
from pyomo.opt import SolverFactory


def solve_with_cap(cap_value, demand_index_to_change):
    H = range(24)
    model = ConcreteModel()
    model.H = Set(initialize=H)

    model.x = Var(model.H, domain=NonNegativeIntegers)
    model.y = Var(model.H, domain=NonNegativeIntegers)
    model.s_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_minus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_plus = Var(model.H, domain=NonNegativeIntegers)
    model.s_prime_minus = Var(model.H, domain=NonNegativeIntegers)

  
    model.cap_constraint = Constraint(model.H, rule=lambda m,i: m.x[i] + m.y[i] <= 100)

   
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]

    model.win_cap = Constraint(
        range(len(windows)),
        rule=lambda m, k: sum(m.x[j]+m.y[j] for j in windows[k]) <= 420
    )
    model.win_min = Constraint(
        range(len(windows)),
        rule=lambda m, k: sum(m.x[j]+m.y[j] for j in windows[k]) >= 80
    )

 
    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    def demand_rule_x_low(m, k):
        if k == demand_index_to_change:
            return sum(m.x[j] for j in windows[k]) >= cap_value - m.s_minus[k]
        return sum(m.x[j] for j in windows[k]) >= demands_x[k] - m.s_minus[k]

    def demand_rule_x_high(m, k):
        if k == demand_index_to_change:
            return sum(m.x[j] for j in windows[k]) <= cap_value + m.s_plus[k]
        return sum(m.x[j] for j in windows[k]) <= demands_x[k] + m.s_plus[k]

    def demand_rule_y_low(m, k):
        return sum(m.y[j] for j in windows[k]) >= demands_y[k] - m.s_prime_minus[k]

    def demand_rule_y_high(m, k):
        return sum(m.y[j] for j in windows[k]) <= demands_y[k] + m.s_prime_plus[k]

    model.demand_x_low  = Constraint(range(len(windows)), rule=demand_rule_x_low)
    model.demand_x_high = Constraint(range(len(windows)), rule=demand_rule_x_high)
    model.demand_y_low  = Constraint(range(len(windows)), rule=demand_rule_y_low)
    model.demand_y_high = Constraint(range(len(windows)), rule=demand_rule_y_high)

 
    model.s_bounds_minus = Constraint(model.H, rule=lambda m,i: m.s_minus[i] <= 10)
    model.s_bounds_prime = Constraint(model.H, rule=lambda m,i: m.s_prime_minus[i] <= 10)
    model.total_s_minus = Constraint(expr=sum(model.s_minus[i] for i in H) <= 40)
    model.total_s_prime_minus = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)

  
    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    obj_expr  = sum(weights[i]*(model.x[i]+model.y[i]) for i in H)
    obj_expr += 60*sum(model.s_minus[i] for i in range(7,18))
    obj_expr += 30*sum(model.s_minus[i] for i in range(18,24))
    obj_expr += 30*sum(model.s_minus[i] for i in range(0,7))
    obj_expr += 45*sum(model.s_prime_minus[i] for i in H)

    model.obj = Objective(expr=obj_expr, sense=minimize)

  
    result = SolverFactory("cbc").solve(model, tee=False)

   
    is_feasible = (result.solver.status == SolverStatus.ok) and \
                  (result.solver.termination_condition == TerminationCondition.optimal)

  
    sol = {}
    if is_feasible:
        sol = {f"x[{i}]": value(model.x[i]) for i in H}
        sol.update({f"y[{i}]": value(model.y[i]) for i in H})
    return sol, value(model.obj) if is_feasible else None, is_feasible

def check_feasibility(sol, cap_value, demand_index_to_change):
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]
    
    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    
    for i in range(24):
        if sol[f"x[{i}]"] + sol[f"y[{i}]"] > 100:
            return False

 
    for k, win in enumerate(windows):
        total = sum(sol[f"x[{j}]"] + sol[f"y[{j}]"] for j in win)
        if total > 420 or total < 80:
            return False

  
    for k, win in enumerate(windows):
        x_sum = sum(sol[f"x[{j}]"] for j in win)
        y_sum = sum(sol[f"y[{j}]"] for j in win)
        
        
        if k == demand_index_to_change:
            if x_sum < cap_value - sol[f"s_minus[{k}]"] or x_sum > cap_value + sol[f"s_plus[{k}]"]:
                return False
        else:
            if x_sum < demands_x[k] - sol[f"s_minus[{k}]"] or x_sum > demands_x[k] + sol[f"s_plus[{k}]"]:
                return False
        
      
        if y_sum < demands_y[k] - sol[f"s_prime_minus[{k}]"] or y_sum > demands_y[k] + sol[f"s_prime_plus[{k}]"]:
            return False

   
    if any(sol[f"s_minus[{i}]"] > 10 for i in range(24)):
        return False
    if any(sol[f"s_prime_minus[{i}]"] > 10 for i in range(24)):
        return False
    if sum(sol[f"s_minus[{i}]"] for i in range(24)) > 40:
        return False
    if sum(sol[f"s_prime_minus[{i}]"] for i in range(24)) > 30:
        return False

    return True



#جواب اولیه
initial_sol = {
    f"x[{i}]": v for i, v in enumerate(
        [0,0,0,0,6,33,21,56,57,48,16,43,47,2,50,71,26,61,40,26,37,29,24,0])
}
initial_sol.update({
    f"y[{i}]": v for i, v in enumerate(
        [0,4,0,13,24,0,29,44,0,29,28,0,49,38,23,29,31,23,30,24,3,0,13,0])
})
initial_sol.update({
    f"s_minus[{i}]": v for i, v in enumerate(
        [0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,4,0,10,0,3,10])
})
initial_sol.update({
    f"s_prime_minus[{i}]": v for i, v in enumerate(
        [0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,6,3,0,0,0,0])
})
initial_sol.update({f"s_plus[{i}]": v for i,v in enumerate(
    [7,0,0,3,0,9,0,0,0,0,1,37,0,33,0,0,3,0,0,0,0,0,0,0])
})
initial_sol.update({f"s_prime_plus[{i}]": 0 for i,v in enumerate(
    [0,0,0,0,0,1,17,0,0,0,0,0,0,0,47,17,0,0,0,0,0,0,0,0])
})


#تحلیل حساسیت
demand_index_to_change = 6
base_cap = 60
MIN_CAP = 0
MAX_CAP = 200

# حل اولیه
base_sol, base_obj = initial_sol, 184848
print(f"Demand_x changed at window: {demand_index_to_change}")
print("Base objective =", base_obj)

#کران بالا
cap = base_cap + 1
while cap <= MAX_CAP:
    
    new_sol, new_obj, new_feas = solve_with_cap(cap, demand_index_to_change)
    
    if check_feasibility(base_sol , cap , demand_index_to_change)==False:
        print(f"\n❌ جواب دیگر feasible نیست در cap = {cap}")
        break
    if int(new_obj) <= 184847:
        print(f"\n❌ جواب اولیه دیگر بهینه نیست در cap = {cap}")
        base_sol = new_sol
        base_obj = new_obj
        print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
        break
    cap += 1

#کران پایین
cap = base_cap - 1
while cap >= MIN_CAP:
    new_sol, new_obj, new_feas = solve_with_cap(cap, demand_index_to_change)
    
    if check_feasibility(base_sol , cap , demand_index_to_change)==False :
        print(f"\n❌ جواب دیگر feasible نیست در cap = {cap}")
        break
    if int(new_obj) <= 184847 :
        print(f"\n❌ جواب اولیه دیگر بهینه نیست در cap = {cap}")
        base_sol = new_sol
        base_obj = new_obj
        print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
        break
    cap -= 1

print("\n✅ تحلیل حساسیت کامل شد")
