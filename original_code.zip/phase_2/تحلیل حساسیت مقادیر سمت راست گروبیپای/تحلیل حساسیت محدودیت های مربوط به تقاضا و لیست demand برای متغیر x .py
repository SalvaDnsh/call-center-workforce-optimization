from gurobipy import *

def solve_with_cap_gurobi(cap_value, demand_index_to_change):
    H = range(24)
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]

    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,
                 240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,
                 150,160,120,130,160,180,200,170,140,110,100,90]

    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    model = Model()

    # متغیرها
    x = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="y")
    s_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_plus")
    s_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_minus")
    s_prime_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_plus")
    s_prime_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_minus")

    # قیود ظرفیت هر ساعت
    for i in H:
        model.addConstr(x[i] + y[i] <= 100, name=f"cap_{i}")

    # قیود پنجره‌ای کران بالا و پایین (جمع x,y در پنجره)
    for k in range(len(windows)):
        model.addConstr(quicksum(x[j] + y[j] for j in windows[k]) <= 420, name=f"win_cap_{k}")
        model.addConstr(quicksum(x[j] + y[j] for j in windows[k]) >= 80, name=f"win_min_{k}")

    # قیود تقاضا برای x با تغییر در پنجره demand_index_to_change
    for k in range(len(windows)):
        if k == demand_index_to_change:
            model.addConstr(quicksum(x[j] for j in windows[k]) >= cap_value - s_minus[k], name=f"demand_x_low_{k}")
            model.addConstr(quicksum(x[j] for j in windows[k]) <= cap_value + s_plus[k], name=f"demand_x_high_{k}")
        else:
            model.addConstr(quicksum(x[j] for j in windows[k]) >= demands_x[k] - s_minus[k], name=f"demand_x_low_{k}")
            model.addConstr(quicksum(x[j] for j in windows[k]) <= demands_x[k] + s_plus[k], name=f"demand_x_high_{k}")

    # قیود تقاضا برای y همیشه ثابت
    for k in range(len(windows)):
        model.addConstr(quicksum(y[j] for j in windows[k]) >= demands_y[k] - s_prime_minus[k], name=f"demand_y_low_{k}")
        model.addConstr(quicksum(y[j] for j in windows[k]) <= demands_y[k] + s_prime_plus[k], name=f"demand_y_high_{k}")

    # کران‌های slack
    for i in H:
        model.addConstr(s_minus[i] <= 10, name=f"s_minus_cap_{i}")
        model.addConstr(s_prime_minus[i] <= 10, name=f"s_prime_minus_cap_{i}")

    model.addConstr(quicksum(s_minus[i] for i in H) <= 40, name="total_s_minus")
    model.addConstr(quicksum(s_prime_minus[i] for i in H) <= 30, name="total_s_prime_minus")

    # تابع هدف
    obj = quicksum(weights[i] * (x[i] + y[i]) for i in H)
    obj += 60 * quicksum(s_minus[i] for i in range(7,18))
    obj += 30 * quicksum(s_minus[i] for i in list(range(18,24)) + list(range(0,7)))
    obj += 45 * quicksum(s_prime_minus[i] for i in H)

    model.setObjective(obj, GRB.MINIMIZE)

    model.Params.OutputFlag = 0  # خاموش کردن گزارش‌ها

    model.optimize()

    is_feasible = model.status == GRB.OPTIMAL

    sol = {}
    if is_feasible:
        for i in H:
            sol[f"x[{i}]"] = x[i].X
            sol[f"y[{i}]"] = y[i].X
            sol[f"s_minus[{i}]"] = s_minus[i].X
            sol[f"s_plus[{i}]"] = s_plus[i].X
            sol[f"s_prime_minus[{i}]"] = s_prime_minus[i].X
            sol[f"s_prime_plus[{i}]"] = s_prime_plus[i].X

    return sol, model.ObjVal if is_feasible else None, is_feasible


def check_feasibility(sol, cap_value, demand_index_to_change):
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]
    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    # چک ظرفیت هر ساعت
    for i in range(24):
        if sol.get(f"x[{i}]", 0) + sol.get(f"y[{i}]", 0) > 100:
            return False

    # چک پنجره‌ها
    for k, win in enumerate(windows):
        total = sum(sol.get(f"x[{j}]", 0) + sol.get(f"y[{j}]", 0) for j in win)
        if total > 420 or total < 80:
            return False

    # چک محدودیت تقاضا
    for k, win in enumerate(windows):
        x_sum = sum(sol.get(f"x[{j}]", 0) for j in win)
        y_sum = sum(sol.get(f"y[{j}]", 0) for j in win)
        if k == demand_index_to_change:
            if x_sum < cap_value - sol.get(f"s_minus[{k}]", 0) or x_sum > cap_value + sol.get(f"s_plus[{k}]", 0):
                return False
        else:
            if x_sum < demands_x[k] - sol.get(f"s_minus[{k}]", 0) or x_sum > demands_x[k] + sol.get(f"s_plus[{k}]", 0):
                return False
        if y_sum < demands_y[k] - sol.get(f"s_prime_minus[{k}]", 0) or y_sum > demands_y[k] + sol.get(f"s_prime_plus[{k}]", 0):
            return False

    # چک slack
    if any(sol.get(f"s_minus[{i}]", 0) > 10 for i in range(24)):
        return False
    if any(sol.get(f"s_prime_minus[{i}]", 0) > 10 for i in range(24)):
        return False
    if sum(sol.get(f"s_minus[{i}]", 0) for i in range(24)) > 40:
        return False
    if sum(sol.get(f"s_prime_minus[{i}]", 0) for i in range(24)) > 30:
        return False

    return True


# ======= جواب اولیه دستی =======
initial_sol = {
    f"x[{i}]": v for i, v in enumerate(
        [0,0,0,0,6,33,21,56,57,48,16,43,47,2,50,71,26,61,40,26,37,29,24,0])
}
initial_sol.update({
    f"y[{i}]": v for i, v in enumerate(
        [0,4,0,13,24,0,29,44,0,29,28,0,49,38,23,29,31,23,30,24,3,0,13,0])
})
initial_sol.update({
    f"s_minus[{i}]": v for i, v in enumerate(
        [0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,4,0,10,0,3,10])
})
initial_sol.update({
    f"s_prime_minus[{i}]": v for i, v in enumerate(
        [0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,6,3,0,0,0,0])
})
initial_sol.update({f"s_plus[{i}]": 0 for i in range(24)})
initial_sol.update({f"s_prime_plus[{i}]": 0 for i in range(24)})


# ========== تحلیل حساسیت ==========

demand_index_to_change = 3
base_cap = 50
MIN_CAP = 0
MAX_CAP = 200

base_sol = initial_sol
base_obj = 184848
print(f"Demand_x changed at window: {demand_index_to_change}")
print("Base objective =", base_obj)
lower_bound = base_cap
upper_bound = base_cap
# افزایش کران
cap = base_cap + 1
while cap <= MAX_CAP:
    new_sol, new_obj, new_feas = solve_with_cap_gurobi(cap, demand_index_to_change)

    if not check_feasibility(base_sol, cap, demand_index_to_change):
        print(f"\n❌ جواب دیگر feasible نیست در cap = {cap}")
        break

    if new_obj is not None and int(new_obj) <= 184847:
        print(f"\n❌ جواب اولیه دیگر بهینه نیست در cap = {cap}")
        base_sol = new_sol
        base_obj = new_obj
        print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
        break
    upper_bound = cap
    cap += 1

# کاهش کران
cap = base_cap - 1
while cap >= MIN_CAP:
    new_sol, new_obj, new_feas = solve_with_cap_gurobi(cap, demand_index_to_change)

    if not check_feasibility(base_sol, cap, demand_index_to_change):
        print(f"\n❌ جواب دیگر feasible نیست در cap = {cap}")
        break

    if new_obj is not None and int(new_obj) <= 184847:
        print(f"\n❌ جواب اولیه دیگر بهینه نیست در cap = {cap}")
        base_sol = new_sol
        base_obj = new_obj
        print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
        break
    lower_bound = cap
    cap -= 1

print("\n✅ تحلیل حساسیت کامل شد")
print(f"\n✅ بازه‌ای که جواب پایه بهینه باقی می‌ماند:\nاز cap = {lower_bound} تا cap = {upper_bound}")
