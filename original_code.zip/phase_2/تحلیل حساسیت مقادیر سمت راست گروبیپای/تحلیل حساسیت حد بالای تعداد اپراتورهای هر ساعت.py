from gurobipy import *

def solve_with_window20_upper_bound_gurobi(upper_bound_value):
    H = range(24)
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18],
        [13,14,15,17,18,19], [14,15,16,18,19,20], [15,16,17,19,20,21],
        [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]

    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,
                 240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,
                 150,160,120,130,160,180,200,170,140,110,100,90]

    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    model = Model()

    # متغیرها
    x = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="x")
    y = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="y")
    s_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_plus")
    s_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_minus")
    s_prime_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_plus")
    s_prime_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_minus")

    # قید ظرفیت: x[i] + y[i] <= 100
    for i in H:
        model.addConstr(x[i] + y[i] <= 100, name=f"cap_constraint_{i}")

    # قیدهای پنجره‌ای کران پایین (80) برای همه پنجره‌ها
    for w in H:
        model.addConstr(quicksum(x[j] + y[j] for j in windows[w]) >= 80, name=f"win_lower_{w}")

    # کران بالای پنجره 20 برابر با مقدار ورودی
    model.addConstr(quicksum(x[j] + y[j] for j in windows[20]) <= upper_bound_value, name="win_upper_10")

    # کران بالای سایر پنجره‌ها ثابت برابر 420
    for w in list(range(0,20)) + list(range(21,24)):
        model.addConstr(quicksum(x[j] + y[j] for j in windows[w]) <= 420, name=f"win_upper_{w}")

    # قیدهای تقاضا برای x
    for i in H:
        model.addConstr(quicksum(x[j] for j in windows[i]) >= demands_x[i] - s_minus[i], name=f"demand_x_low_{i}")
        model.addConstr(quicksum(x[j] for j in windows[i]) <= demands_x[i] + s_plus[i], name=f"demand_x_high_{i}")

    # قیدهای تقاضا برای y
    for i in H:
        model.addConstr(quicksum(y[j] for j in windows[i]) >= demands_y[i] - s_prime_minus[i], name=f"demand_y_low_{i}")
        model.addConstr(quicksum(y[j] for j in windows[i]) <= demands_y[i] + s_prime_plus[i], name=f"demand_y_high_{i}")

    # سقف برای s_minus و s_prime_minus در هر ساعت
    for i in H:
        model.addConstr(s_minus[i] <= 10, name=f"s_minus_cap_{i}")
        model.addConstr(s_prime_minus[i] <= 10, name=f"s_prime_minus_cap_{i}")

    # سقف مجموع s_minus و s_prime_minus
    model.addConstr(quicksum(s_minus[i] for i in H) <= 40, name="total_s_minus_cap")
    model.addConstr(quicksum(s_prime_minus[i] for i in H) <= 30, name="total_s_prime_minus_cap")

    # تابع هدف
    obj = quicksum(weights[i] * (x[i] + y[i]) for i in H) \
          + 60 * quicksum(s_minus[i] for i in range(7,18)) \
          + 30 * quicksum(s_minus[i] for i in list(range(18,24)) + list(range(0,7))) \
          + 45 * quicksum(s_prime_minus[i] for i in H)

    model.setObjective(obj, GRB.MINIMIZE)

    model.Params.OutputFlag = 0  # خاموش کردن لاگ

    model.optimize()

    sol = {}
    for i in H:
        sol[f"x[{i}]"] = x[i].X
        sol[f"y[{i}]"] = y[i].X
        sol[f"s_minus[{i}]"] = s_minus[i].X
        sol[f"s_plus[{i}]"] = s_plus[i].X
        sol[f"s_prime_minus[{i}]"] = s_prime_minus[i].X
        sol[f"s_prime_plus[{i}]"] = s_prime_plus[i].X

    return sol

def is_feasible_window20(sol, upper_bound_value):
    windows_20 = [14,15,16,18,19,20]
    return sum(sol[f"x[{j}]"] + sol[f"y[{j}]"] for j in windows_20) <= upper_bound_value

def compute_objective(sol):
    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]
    H = range(24)
    val = sum(weights[i]*(sol[f"x[{i}]"] + sol[f"y[{i}]"]) for i in H)
    val += 60*sum(sol[f"s_minus[{i}]"] for i in range(7,18))
    val += 30*sum(sol[f"s_minus[{i}]"] for i in list(range(18,24)) + list(range(0,7)))
    val += 45*sum(sol[f"s_prime_minus[{i}]"] for i in H)
    return val


# ========== تحلیل حساسیت Upper Bound window 20 ==========

# جواب اولیه دستی (همانطور که داده‌اید)
initial_sol = {
    f"x[{i}]": v for i, v in enumerate(
        [0,0,0,0,6,33,21,56,57,48,16,43,47,2,50,71,26,61,40,26,37,29,24,0])
}
initial_sol.update({
    f"y[{i}]": v for i, v in enumerate(
        [0,4,0,13,24,0,29,44,0,29,28,0,49,38,23,29,31,23,30,24,3,0,13,0])
})
initial_sol.update({
    f"s_minus[{i}]": v for i, v in enumerate(
        [0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,4,0,10,0,3,10])
})
initial_sol.update({
    f"s_prime_minus[{i}]": v for i, v in enumerate(
        [0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,6,3,0,0,0,0])
})
initial_sol.update({f"s_plus[{i}]": 0 for i in range(24)})
initial_sol.update({f"s_prime_plus[{i}]": 0 for i in range(24)})

base_bound = 420
MIN_BOUND = 0
MAX_BOUND = 800

base_sol = initial_sol
base_obj = compute_objective(base_sol)
print("✅ شروع از جواب اولیه | objective =", base_obj)
lower_bound = base_bound
upper_bound = base_bound

# کران بالا
bound = base_bound + 1
while bound <= MAX_BOUND:
    if not is_feasible_window20(base_sol, bound):
        print(f"\n❌ جواب اولیه دیگر feasible نیست در window 20 با کران بالا = {bound}")
        base_sol = solve_with_window20_upper_bound_gurobi(bound)
        base_obj = compute_objective(base_sol)
        print(f"جواب جدید پیدا شد، objective = {base_obj}")
        break
    else:
        new_sol = solve_with_window20_upper_bound_gurobi(bound)
        new_obj = compute_objective(new_sol)
        if int(new_obj) < 184847:
            print(f"\n❌ جواب اولیه دیگر بهینه نیست در window 20 با کران بالا = {bound}")
            base_sol = new_sol
            base_obj = new_obj
            print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
            break
        upper_bound = bound
    bound += 1

# کران پایین
bound = base_bound - 1
while bound >= MIN_BOUND:
    if not is_feasible_window20(base_sol, bound):
        print(f"\n❌ جواب اولیه دیگر feasible نیست در window 20 با کران بالا = {bound}")
        base_sol = solve_with_window20_upper_bound_gurobi(bound)
        base_obj = compute_objective(base_sol)
        print(f"جواب جدید پیدا شد، objective = {base_obj}")
        break
    else:
        new_sol = solve_with_window20_upper_bound_gurobi(bound)
        new_obj = compute_objective(new_sol)
        if int(new_obj) <= 184847:
            print(f"\n❌ جواب اولیه دیگر بهینه نیست در window 20 با کران بالا = {bound}")
            base_sol = new_sol
            base_obj = new_obj
            print(f"جواب جدید بهتر پیدا شد، objective = {base_obj}")
            break
        lower_bound = bound
    bound -= 1

print("\n✅ تحلیل حساسیت روی Upper Bound window 20 کامل شد")
print(f"\n✅ بازه‌ای که جواب پایه بهینه باقی می‌ماند:\nاز cap = {lower_bound} تا cap = {upper_bound}")
