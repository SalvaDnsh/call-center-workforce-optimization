from pyomo.environ import *


#مدل را ایجاد می‌کنیم
model = ConcreteModel()

#تعریف مجموعه ساعتها
H = range(24)

# تعریف متغیرها
model.x = Var(H, domain=NonNegativeIntegers)
model.y = Var(H, domain=NonNegativeIntegers)
model.s_plus = Var(H, domain=NonNegativeIntegers)
model.s_minus = Var(H, domain=NonNegativeIntegers)
model.s_prime_plus = Var(H, domain=NonNegativeIntegers)
model.s_prime_minus = Var(H, domain=NonNegativeIntegers)

#محدودیت ظرفیت 100 نفره برای هر شیفت
def cap_rule(m, i):
    return m.x[i] + m.y[i] <= 100
model.Capacity = Constraint(H, rule=cap_rule)

#تعریف ساعت‌های کاری هر شیفت
windows = [
    [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
    [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
    [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
    [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
    [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18],
    [13,14,15,17,18,19], [14,15,16,18,19,20], [15,16,17,19,20,21],
    [16,17,18,20,21,22], [17,18,19,21,22,23]
]

#محدودیت ظرفیت تعداد کارمندان در هر ساعت
model.CapacityWin = ConstraintList()
for win in windows:
    model.CapacityWin.add(sum(model.x[j] + model.y[j] for j in win) <= 420)
    model.CapacityWin.add(sum(model.x[j] + model.y[j] for j in win) >= 80)

#محدودیت های تقاضای هر ساعت
demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,
             240,220,220,230,250,260,230,250,260,250,220,190]
demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,
             150,160,120,130,160,180,200,170,140,110,100,90]

model.Demand = ConstraintList()
for i, win in enumerate(windows):
    model.Demand.add(sum(model.x[j] for j in win) >= demands_x[i] - model.s_minus[i])
    model.Demand.add(sum(model.x[j] for j in win) <= demands_x[i] + model.s_plus[i])
    model.Demand.add(sum(model.y[j] for j in win) >= demands_y[i] - model.s_prime_minus[i])
    model.Demand.add(sum(model.y[j] for j in win) <= demands_y[i] + model.s_prime_plus[i])

#محدودیت های مربوط به متغیرهای کمبود
model.SBounds = ConstraintList()
for i in H:
    model.SBounds.add(model.s_minus[i] <= 10)
    model.SBounds.add(model.s_prime_minus[i] <= 10)

#محدودیت های مربوط به مجموع کمبودها برای هر شرکت
model.Total_s_minus = Constraint(expr=sum(model.s_minus[i] for i in H) <= 40)
model.Total_s_prime_minus = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)

#ذخیره ضرایب تابع هدف در یک لیست
weights = [189,189,189,180,171,162,153,144,135,126,126,135,
           144,153,162,171,180,189,189,189,189,189,189,189]

model.obj = Objective(
    expr=sum(weights[i]*(model.x[i]+model.y[i]) for i in H)
         + 60*sum(model.s_minus[i] for i in range(7,18))
         + 30*sum(model.s_minus[i] for i in range(18,24))
         + 30*sum(model.s_minus[i] for i in range(0,7))
         + 45*sum(model.s_prime_minus[i] for i in H),
    sense=minimize
)

#مدل با سالور cbc حل می‌شود
solver = SolverFactory("cbc")
results = solver.solve(model, tee=True)
for v in model.component_objects(Var, active=True):
    for index in v:
        print(v[index].name, "=", v[index].value)

print("Objective =", value(model.obj))

