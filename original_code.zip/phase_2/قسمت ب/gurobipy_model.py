import gurobipy as gp
from gurobipy import GRB
# ایجاد مدل
model = gp.Model("Hourly_Capacity_Model")

H = range(24)
# متغیرها
x = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="x")
y = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="y")

s_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_plus")
s_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_minus")

s_prime_plus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_plus")
s_prime_minus = model.addVars(H, vtype=GRB.INTEGER, lb=0, name="s_prime_minus")
# محدودیت ظرفیت هر ساعت
for i in H:
    model.addConstr(x[i] + y[i] <= 100, name=f"Cap_{i}")
# پنجره‌های 7 ساعته
windows = [
    [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
    [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
    [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
    [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
    [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
    [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
]
# ظرفیت پنجره‌ها
for k, win in enumerate(windows):
    model.addConstr(
        gp.quicksum(x[j] + y[j] for j in win) <= 420,
        name=f"WinCapMax_{k}"
    )
    model.addConstr(
        gp.quicksum(x[j] + y[j] for j in win) >= 80,
        name=f"WinCapMin_{k}"
    )
# محدودیت‌های تقاضا
demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

for i, win in enumerate(windows):
    model.addConstr(
        gp.quicksum(x[j] for j in win) >= demands_x[i] - s_minus[i],
        name=f"DemandX_L_{i}"
    )
    model.addConstr(
        gp.quicksum(x[j] for j in win) <= demands_x[i] + s_plus[i],
        name=f"DemandX_U_{i}"
    )

    model.addConstr(
        gp.quicksum(y[j] for j in win) >= demands_y[i] - s_prime_minus[i],
        name=f"DemandY_L_{i}"
    )
    model.addConstr(
        gp.quicksum(y[j] for j in win) <= demands_y[i] + s_prime_plus[i],
        name=f"DemandY_U_{i}"
    )
# کران‌های s_minus
for i in H:
    model.addConstr(s_minus[i] <= 10, name=f"Smin_{i}")
    model.addConstr(s_prime_minus[i] <= 10, name=f"Sprimemin_{i}")

model.addConstr(gp.quicksum(s_minus[i] for i in H) <= 40, name="Total_s_minus")
model.addConstr(gp.quicksum(s_prime_minus[i] for i in H) <= 30, name="Total_s_prime_minus")
# تابع هدف
weights = [189,189,189,180,171,162,153,144,135,126,126,135,
           144,153,162,171,180,189,189,189,189,189,189,189]

objective = (
    gp.quicksum(weights[i] * (x[i] + y[i]) for i in H)
    + 60 * gp.quicksum(s_minus[i] for i in range(7,18))
    + 30 * gp.quicksum(s_minus[i] for i in range(18,24))
    + 30 * gp.quicksum(s_minus[i] for i in range(0,7))
    + 45 * gp.quicksum(s_prime_minus[i] for i in H)
)

model.setObjective(objective, GRB.MINIMIZE)
# حل مدل
model.optimize()
# نمایش همه متغیرها و مقادیرشان و نتایج
if model.status == GRB.OPTIMAL:
    print("\nOptimal Solution:\n")
    for v in model.getVars():
        val = v.x
        print(f"{v.varName} = {val}")
    print("\nObjective value =", model.objVal)