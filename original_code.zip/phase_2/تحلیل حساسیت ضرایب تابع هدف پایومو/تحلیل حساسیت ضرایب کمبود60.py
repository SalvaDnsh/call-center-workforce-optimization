from pyomo.environ import *

# ---------------- تابع حل با تغییر ضریب 60 ----------------
def solve_with_cs(weight_value, index_to_change):
    H = range(24)
    model = ConcreteModel()

    # ---- متغیرها ----
    model.x = Var(H, domain=NonNegativeIntegers)
    model.y = Var(H, domain=NonNegativeIntegers)
    model.s_plus = Var(H, domain=NonNegativeIntegers)
    model.s_minus = Var(H, domain=NonNegativeIntegers)
    model.s_prime_plus = Var(H, domain=NonNegativeIntegers)
    model.s_prime_minus = Var(H, domain=NonNegativeIntegers)

    # ---- محدودیت ظرفیت ----
    model.cap = Constraint(H, rule=lambda m, i: m.x[i] + m.y[i] <= 100)

    # ---- پنجره‌ها ----
    windows = [
        [18,19,20,22,23,0], [19,20,21,23,0,1], [20,21,22,0,1,2], [21,22,23,1,2,3],
        [22,23,0,2,3,4], [23,0,1,3,4,5], [0,1,2,4,5,6], [1,2,3,5,6,7],
        [2,3,4,6,7,8], [3,4,5,7,8,9], [4,5,6,8,9,10], [5,6,7,9,10,11],
        [6,7,8,10,11,12], [7,8,9,11,12,13], [8,9,10,12,13,14], [9,10,11,13,14,15],
        [10,11,12,14,15,16], [11,12,13,15,16,17], [12,13,14,16,17,18], [13,14,15,17,18,19],
        [14,15,16,18,19,20], [15,16,17,19,20,21], [16,17,18,20,21,22], [17,18,19,21,22,23]
    ]

    # ---- محدودیت پنجره ----
    model.win_upper = Constraint(range(24),
        rule=lambda m, w: sum(m.x[j] + m.y[j] for j in windows[w]) <= 420)
    model.win_lower = Constraint(range(24),
        rule=lambda m, w: sum(m.x[j] + m.y[j] for j in windows[w]) >= 80)

    # ---- تقاضا ----
    demands_x = [120,95,90,50,30,30,60,110,140,200,180,180,240,220,220,230,250,260,230,250,260,250,220,190]
    demands_y = [70,40,20,30,50,40,40,90,110,110,110,130,150,160,120,130,160,180,200,170,140,110,100,90]

    model.dx_l = Constraint(range(24),
        rule=lambda m, i: sum(m.x[j] for j in windows[i]) >= demands_x[i] - m.s_minus[i])
    model.dx_u = Constraint(range(24),
        rule=lambda m, i: sum(m.x[j] for j in windows[i]) <= demands_x[i] + m.s_plus[i])
    model.dy_l = Constraint(range(24),
        rule=lambda m, i: sum(m.y[j] for j in windows[i]) >= demands_y[i] - m.s_prime_minus[i])
    model.dy_u = Constraint(range(24),
        rule=lambda m, i: sum(m.y[j] for j in windows[i]) <= demands_y[i] + m.s_prime_plus[i])

    # ---- کران slack ها ----
    model.s_minus_cap = Constraint(H, rule=lambda m, i: m.s_minus[i] <= 10)
    model.s_prime_minus_cap = Constraint(H, rule=lambda m, i: m.s_prime_minus[i] <= 10)

    model.total_s_minus = Constraint(expr=sum(model.s_minus[i] for i in H) <= 40)
    model.total_s_prime_minus = Constraint(expr=sum(model.s_prime_minus[i] for i in H) <= 30)

    # ---- ضرایب تابع هدف ----
    weights = [189,189,189,180,171,162,153,144,135,126,126,135,
               144,153,162,171,180,189,189,189,189,189,189,189]

    model.c_s = Param(range(7,18), initialize=60, mutable=True)

    model.c_s[index_to_change].set_value(weight_value)

    # ---- تابع هدف ----
    model.obj = Objective(
    expr=
        sum(weights[i]*model.x[i] + weights[i]*model.y[i] for i in H)
        + sum(model.c_s[i] * model.s_minus[i] for i in range(7,18))
        + 30 * sum(model.s_minus[i] for i in range(18,24))
        + 30 * sum(model.s_minus[i] for i in range(0,7))
        + 45 * sum(model.s_prime_minus[i] for i in H),
    sense=minimize
)


    solver = SolverFactory('cbc')
    solver.solve(model, tee=False)

    sol = {
        **{f"x[{i}]": model.x[i].value for i in H},
        **{f"y[{i}]": model.y[i].value for i in H},
        **{f"s_minus[{i}]": model.s_minus[i].value for i in H},
        **{f"s_prime_minus[{i}]": model.s_prime_minus[i].value for i in H},
    }

    return sol, value(model.obj)


# ---------------- تابع مقایسه جواب‌ها ----------------
def compare_solutions(sol1, sol2, tolerance=1e-6):
    changed_vars = {}
    for key in sol1:
        if abs(sol1[key] - sol2[key]) > tolerance:
            changed_vars[key] = (sol1[key], sol2[key])
    return changed_vars


# ---------------- تحلیل حساسیت ضریب s_minus[17] ----------------
index_to_change = 17
base_weight = 60

base_sol, base_obj = solve_with_cs(
    base_weight,
    index_to_change=index_to_change
)

print(f"Base objective =", base_obj)

# ---- کران بالا ----
weight = base_weight + 1
max_iter = 50
iter_count = 0
last_weight = base_weight

while iter_count < max_iter:
    sol, obj = solve_with_cs(weight, index_to_change=index_to_change)
    
    # مقدار متغیر تصمیم در حالت پایه
    x_val_base = base_sol[f"x[{index_to_change}]"]
    
    # مقدار تغییری که در وزن ایجاد کردیم
    delta_weight = weight - base_weight
    
    # اگر استراتژی پایه هنوز بهینه باشد، تابع هدف باید دقیقاً به اندازه (تغییر وزن * مقدار متغیر) تغییر کند
    expected_obj = base_obj + (delta_weight * x_val_base)
    
    # بررسی: آیا حل‌گر راهی ارزان‌تر از انتظار ما پیدا کرده؟
    # (از یک اپسیلون کوچک برای خطای اعشاری استفاده میکنیم)
    if obj < expected_obj - 1e-5:
        print(f"Basis changed at weight {weight}. Found cheaper obj: {obj} < {expected_obj}")
        break
    else:
        last_weight = weight
        weight += 1
    iter_count += 1

upper_bound = last_weight

# ---- کران پایین ----
weight = base_weight - 1
iter_count = 0
last_weight = base_weight

while iter_count < max_iter and weight>0:
    sol, obj = solve_with_cs(weight, index_to_change=index_to_change)
    
    # مقدار متغیر تصمیم در حالت پایه
    x_val_base = base_sol[f"x[{index_to_change}]"]
    
    # مقدار تغییری که در وزن ایجاد کردیم
    delta_weight = weight - base_weight
    
    # اگر استراتژی پایه هنوز بهینه باشد، تابع هدف باید دقیقاً به اندازه (تغییر وزن * مقدار متغیر) تغییر کند
    expected_obj = base_obj + (delta_weight * x_val_base)
    
    # بررسی: آیا حل‌گر راهی ارزان‌تر از انتظار ما پیدا کرده؟
    # (از یک اپسیلون کوچک برای خطای اعشاری استفاده میکنیم)
    if obj < expected_obj - 1e-5:
        print(f"Basis changed at weight {weight}. Found cheaper obj: {obj} < {expected_obj}")
        break
    else:
        last_weight = weight
        weight -= 1 
    iter_count += 1
lower_bound = last_weight

print(f"Sensitivity range for c_s[{index_to_change}]:")
print("Lower bound =", lower_bound)
print("Upper bound =", upper_bound)


# ---------------- نمایش متغیرهای تغییر یافته ----------------
print("\n🔍 متغیرهای تغییر یافته:")
diffs = compare_solutions(base_sol, sol)
for var, (v1, v2) in diffs.items():
    print(f"{var}: {v1} → {v2}")
